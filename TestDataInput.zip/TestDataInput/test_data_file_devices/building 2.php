<?php
$building_devs = array(
    "device 0" => array("ID" => "000D6F00028EDD69", "name" => "fridge", "type" => 11),
    "device 1" => array("ID" => "000D6F00035616E3", "name" => "dishwasher", "type" => 107),
    "device 2" => array("ID" => "000D6F00035616EC", "name" => "microwave", "type" => 44),
    "device 3" => array("ID" => "000D6F0003561CCB", "name" => "water_kettle", "type" => 33),
    "device 4" => array("ID" => "000D6F0003561F97", "name" => "washing_machine", "type" => 105),
    "device 5" => array("ID" => "000D6F0003562C69", "name" => "radio_and_amplifier", "type" => 9),
    "device 6" => array("ID" => "000D6F0003562C6D", "name" => "dryer", "type" => 104),
    "device 7" => array("ID" => "000D6F0003563110", "name" => "kitchenware", "type" => 9),
    "device 8" => array("ID" => "000D6F0003563119", "name" => "bedside_light", "type" => 8)
);
?>