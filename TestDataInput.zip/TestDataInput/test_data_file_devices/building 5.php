<?php
$building_devs = array(
    "device 0" => array("ID" => "000D6F00029C2918", "name" => "total_outlet", "type" => 9),
    "device 1" => array("ID" => "000D6F00029C286E", "name" => "total_lights", "type" => 8),
    "device 2" => array("ID" => "000D6F00029C44E4", "name" => "kitchen_TV", "type" => 14),
    "device 3" => array("ID" => "000D6F00029C46A3", "name" => "living_room_TV", "type" => 14),
    "device 4" => array("ID" => "000D6F00029C246A", "name" => "fridge_and_freezer", "type" => 13),
    "device 5" => array("ID" => "000D6F00029C24E1", "name" => "electric_oven", "type" => 49),
    "device 6" => array("ID" => "000D6F00029C46A6", "name" => "computer_scanner_printer", "type" => 9),
    "device 7" => array("ID" => "000D6F00029C271E", "name" => "washing_machine", "type" => 105),
    "device 8" => array("ID" => "000D6F00029C46A4", "name" => "hood", "type" => 48)
);
?>