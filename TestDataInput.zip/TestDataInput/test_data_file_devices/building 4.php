<?php
$building_devs = array(
    "device 0" => array("ID" => "000D6F00029C2AEB", "name" => "entrance outlet", "type" => 9),
    "device 1" => array("ID" => "000D6F0003561F98", "name" => "dishwasher", "type" => 107),
    "device 2" => array("ID" => "000D6F0003562DF4", "name" => "water_kettle", "type" => 33),
    "device 3" => array("ID" => "000D6F000353AE48", "name" => "fridge_and_freezer", "type" => 13),
    "device 4" => array("ID" => "000D6F00029C2934", "name" => "washing_machine", "type" => 105),
    "device 5" => array("ID" => "000D6F0003562CA8", "name" => "hairdryer", "type" => 93),
    "device 6" => array("ID" => "000D6F0003562D88", "name" => "computer", "type" => 68),
    "device 7" => array("ID" => "000D6F0003562C9D", "name" => "coffee_machine", "type" => 37),
    "device 8" => array("ID" => "000D6F00029C1C2B", "name" => "TV", "type" => 14)
);
?>