<?php
$building_devs = array(
    "device 0" => array("ID" => "000D6F00029C1AE6", "name" => "TV", "type" => 14),
    "device 1" => array("ID" => "000D6F0003561747", "name" => "NAS", "type" => 60),
    "device 2" => array("ID" => "000D6F0003562C4A", "name" => "washing_machine", "type" => 105),
    "device 3" => array("ID" => "000D6F000356174D", "name" => "dryer", "type" => 104),
    "device 4" => array("ID" => "000D6F0003561FFD", "name" => "dishwasher", "type" => 107),
    "device 5" => array("ID" => "000D6F00035606BF", "name" => "notebook", "type" => 67),
    "device 6" => array("ID" => "000D6F0003561744", "name" => "kitchenware", "type" => 9),
    "device 7" => array("ID" => "000D6F0003561C12", "name" => "coffee_machine", "type" => 37),
    "device 8" => array("ID" => "000D6F00035606C0", "name" => "bread_machine", "type" => 47)
);
?>