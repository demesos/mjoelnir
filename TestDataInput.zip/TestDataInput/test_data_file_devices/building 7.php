<?php
$building_devs = array(
    "device 0" => array("ID" => "000D6F00029C2542", "name" => "hair_dryer", "type" => 93),
    "device 1" => array("ID" => "000D6F00036BC42A", "name" => "washing_machine", "type" => 105),
    "device 2" => array("ID" => "000D6F0003BD8082", "name" => "video_game_console_radio", "type" => 9),
    "device 3" => array("ID" => "000D6F0003BD8C8E", "name" => "dryer", "type" => 104),
    "device 4" => array("ID" => "000D6F0003BD76C4", "name" => "TV_decoder_computer_in_living_room", "type" => 9),
    "device 5" => array("ID" => "000D6F0003BD8103", "name" => "kitchen_TV", "type" => 14),
    "device 6" => array("ID" => "000D6F0003BD8293", "name" => "dishwasher", "type" => 107),
    "device 7" => array("ID" => "000D6F0003BD6E92", "name" => "total_outlets", "type" => 9),
    "device 8" => array("ID" => "000D6F0003B9C636", "name" => "total_lights", "type" => 8)
);
?>