<?php
$building_devs = array(
    "device 0" => array("ID" => "000D6F0002906FA7", "name" => "coffee_machine", "type" => 37),
    "device 1" => array("ID" => "000D6F0002907BA2", "name" => "washing_machine", "type" => 105),
    "device 2" => array("ID" => "000D6F0002907BC8", "name" => "radio", "type" => 22),
    "device 3" => array("ID" => "000D6F0002907BDF", "name" => "water_kettle", "type" => 33),
    "device 4" => array("ID" => "000D6F0002907BF5", "name" => "fridge_and_freezer", "type" => 13),
    "device 5" => array("ID" => "000D6F0002907C89", "name" => "dishwasher", "type" => 107),
    "device 6" => array("ID" => "000D6F0002908150", "name" => "kitchen_lamp", "type" => 8),
    "device 7" => array("ID" => "000D6F0002908162", "name" => "TV", "type" => 14),
    "device 8" => array("ID" => "000D6F00029C506A", "name" => "vacuum_cleaner", "type" => 91)
);
?>
