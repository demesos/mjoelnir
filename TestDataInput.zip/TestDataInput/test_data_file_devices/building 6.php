<?php
$building_devs = array(
    "device 0" => array("ID" => "000D6F0003562C6E", "name" => "plasma_TV", "type" => 14),
    "device 1" => array("ID" => "000D6F0003562C89", "name" => "lamp", "type" => 14),
    "device 2" => array("ID" => "000D6F0003561FAD", "name" => "toaster", "type" => 34),
    "device 3" => array("ID" => "000D6F0003562D7D", "name" => "hob", "type" => 48),
    "device 4" => array("ID" => "000D6F000356311B", "name" => "iron", "type" => 97),
    "device 5" => array("ID" => "000D6F000353ACAF", "name" => "computer_scanner_printer", "type" => 9),
    "device 6" => array("ID" => "000D6F0002907069", "name" => "LCD_TV", "type" => 14),
    "device 7" => array("ID" => "000D6F00029C2979", "name" => "washing_machine", "type" => 105),
    "device 8" => array("ID" => "000D6F000353AC93", "name" => "fridge_and_freezer", "type" => 13)
);
?>