<?php
$building_devs = array(
    "device 0" => array("ID" => "000D6F00036BB04C", "name" => "radio", "type" => 22),
    "device 1" => array("ID" => "000D6F00029C2BD7", "name" => "freezer", "type" => 12),
    "device 2" => array("ID" => "000D6F000353AC8C", "name" => "dishwasher", "type" => 107),
    "device 3" => array("ID" => "000D6F0003562E10", "name" => "fridge", "type" => 11),
    "device 4" => array("ID" => "000D6F0003562C48", "name" => "washing_machine", "type" => 105),
    "device 5" => array("ID" => "000D6F00029C2984", "name" => "water_kettle", "type" => 33),
    "device 6" => array("ID" => "000D6F000353AE51", "name" => "blender", "type" => 9),
    "device 7" => array("ID" => "000D6F0003562C0F", "name" => "network_router", "type" => 61)
);
?>