<?php
SESSION_START();

// Including useful php-files with require method
require_once("../../../core/php/methods.php");
require_once("../../../userSettings.php");
require_once("tdi_methods.php");
require_once("../../../core/php/db.connect.php");

/* Script - Start get privilege */
$key = $con->escape($_POST["key"]);
$json = array();
$data = array();
$data[0] = "Needed user privilege";
$data[1] = $con->getPrivileges($key);

$json["data"] = $data;
echo json_encode($json); // sends the needed data back to the client (ajax request)