<?php
    SESSION_START();

    // Including useful php-files with require method
    require_once("../../../core/php/methods.php");
    require_once("../../../userSettings.php");
    require_once("tdi_methods.php");
    require_once("../../../core/php/db.connect.php");

    /* Script - Start users */
    $user = $con->escape($_POST["user"]);
    $json = array();
    $data = array();
    $users_array = array();
    $users_array = $con->getAllUsernames();

    if (count($users_array) >= 1)
    {
        $data[0] = "USERS";
        $data[1] = $users_array;
        $data[2] = count($users_array);
    }
    else
    {
        $data[0] = "NO USERS";
        $data[1] = "No users are signed in at this data base. You must insert users into the data base!";
    }

    $json["data"] = $data;
    echo json_encode($json); // sends the needed data back to the client (ajax request)