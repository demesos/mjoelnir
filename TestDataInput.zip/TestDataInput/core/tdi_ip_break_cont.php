<?php
    SESSION_START();

    // Including useful php-files with require method
    require_once("../../../core/php/methods.php");
    require_once("../../../userSettings.php");
    require_once("tdi_methods.php");
    require_once("../../../core/php/db.connect.php");

    /* Script - Break and continue input process */
    $user = $con->escape($_POST["user"]);
    $building = $con->escape($_POST["building"]);
    $process_var = $con->escape($_POST["process_var"]);
    $json = array();
    $data = array();

    require("../tmp_log_files/le_".$user."_".$building.".php");
    $isf_return_data = array();
    $isf_return_data = getCIFStream($user, $building, "LINE");
    
    if ($process_var == "BREAK") {
        $input_stream_files = $isf_return_data["input stream"]."\"file ".$isf_return_data["next file number"]."\" => array(\"file name\" => \"".$last_entry["log-ID"]."\", \"date\" => \"".$isf_return_data["next file date"]."\", \"input state\" => \"".$process_var."\")); ?>";
        writeFile("../tmp_log_files/","cif_".$user."_".$building.".php", $input_stream_files);
        $data[0] = $process_var; // current input state
        $data[1] = "The insert process has been interrupted! This process can be reactivated, if you press \"CONTINUE\"!"; // info text, tdi-process view
    }
    else {
        $used_insert_key = $con->escape($_POST["insert_key"]);
        if($used_insert_key == $last_entry["insert key"]) {
            $input_stream_files = $isf_return_data["input stream"]."\"file ".$isf_return_data["next file number"]."\" => array(\"file name\" => \"".$last_entry["log-ID"]."\", \"date\" => \"".$isf_return_data["next file date"]."\", \"input state\" => \"NEXT LINES\")); ?>";
            writeFile("../tmp_log_files/","cif_".$user."_".$building.".php", $input_stream_files);
	    $input_stream_last_entry = "<?php \$last_entry = array(\"log-ID\" => \"" .$last_entry["log-ID"]."\", \"user\" => \"".$user."\", \"current line\" => \"".$last_entry["current line"]."\", \"count of rows\" => \"".$last_entry["count of rows"]."\", \"insert key\" => \"".$used_insert_key."\", \"last insert time\" => \"".time()."\"); ?>";
            writeFile("../tmp_log_files/","le_".$user."_".$building.".php", $input_stream_last_entry);
            $data[0] = $process_var; // current input state
            $data[1] = "NEXT LINES"; // next input state
        }
        else {
            $data[0] = "CONTINUING IS STOPPED";
            $data[1] = "This insert process has been interrupted for a long time. So, it has been stopped now!";
        }
    }
    
    $json["data"] = $data;
    echo json_encode($json); // sends the needed data back to the client (ajax request)