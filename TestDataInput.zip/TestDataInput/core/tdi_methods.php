﻿<?php
/* Needed functions for the Test-Data-Input widget */
// normally used to get the file names which are included in, cif_building *.php
if (!function_exists("get_inputtedFiles"))
{
    function get_inputtedFiles($cif_array)
    {
        $data_array = array();

        for($i = 1; $i <= count($cif_array); $i++)
            $data_array[$i-1] = $cif_array["file ".$i]["file name"];

        return $data_array;
    }
}

// checks, if the current file had been inserted already
if (!function_exists("check_inputtedFiles"))
{
    function check_inputtedFiles($file_array, $filename)
    {
        $i = 0;

        while (($i < count($file_array)) && ($file_array[$i] != $filename))
            $i++;

        if ($i == count($file_array))
            return true;
        else
            return false;
    }
}

// checks, if the files CurrentInputtedFiles_*.php, or LastEntry_*.php for the current building exists
if (!function_exists("check_existsFiles"))
{
    function check_existsFiles($tmp_log_files, $count_of_tmp, $current_file)
    {
        $i = 0;

        while (($i < $count_of_tmp) && ($tmp_log_files[$i] != $current_file))
            $i++;

        if ($i == $count_of_tmp)
            return false;
        else
            return true;
    }
}

// counts the lines of the current inserting data file
if (!function_exists("countOfLines"))
{
    function countOfLines($file_directory, $file_name)
    {
        $file_array = file($file_directory.$file_name); // function file, returns the whole file content, and stores it into an array
        $line_count = count($file_array); // counts the array lines
        return $line_count;
    }
}

// inserts all the devices, of the current building (e.g. building 0, ...)
if (!function_exists("insertingDevices")) {
    function insertingDevices($current_authkey, $connection, $user, $building, $room, $room_type, $devices) // room ... description, $current_devs ... inserted devices for the browser
    {
        $user_letters = substr($user, 0, 4); // returns the first four characters of the users
        $building_id = $connection->addBuilding($user, "test_".$building.$user_letters, "0"); // inserts the current building for the specific user to the db
        $connection->addRoomTestData($user, "test_".$building.$user_letters, $room, $room_type); // adds a test data room for building ...
        $circuit_id = $connection->addCircuit($current_authkey, "test_circuit ".$building.$user_letters);
        $connection->modifyCircuit($circuit_id, "b", $building_id);
        $current_devs = array();

        // inserts all devices for the current building
        for($i = 0; $i < count($devices); $i++)
        {
            $connection->addDevice($user, $devices["device ".$i]["ID"].$user_letters, "test_".$devices["device ".$i]["name"]);
            $connection->updateDevType($devices["device ".$i]["ID"].$user_letters, $devices["device ".$i]["type"]);
            $current_devs[$i] = "test_".$devices["device ".$i]["name"];
        }

        return $current_devs;
    }
}

// used to create/overwriting the files cif_building *.php and le_building *.php for the current building
if (!function_exists("writeFile"))
{
    function writeFile($file_directory, $filename, $input_stream)
    {
        // c sets the file pointer at the beginning of the file, but doesn't delete the entry of the file (like w)
        $file = fopen($file_directory.$filename, "w");
        fwrite($file, $input_stream);
        fclose($file);
    }
}

// returns the needed data stream for the file cif_building ....php
if (!function_exists("getCIFStream"))
{
    function getCIFStream($current_user, $current_building, $overwriting_process)
    {
        $input_stream_files = "<?php \$current_inputted_files = array(";
        $input_stream_stop = 0;
        $data = array();
        $help_array_cif = array();
        require("../tmp_log_files/cif_".$current_user."_".$current_building.".php");

        if($overwriting_process == "FILE")
            $input_stream_stop = count($current_inputted_files) + 1;
        else {
            $input_stream_stop = count($current_inputted_files);
            $data["next file date"] = $current_inputted_files["file ".$input_stream_stop]["date"];
        }

        for($i = 1; $i < $input_stream_stop; $i++)
        {
            $help_array_cif = $current_inputted_files["file ".$i];
            $input_stream_files = $input_stream_files."\"file ".$i."\" => array(\"file name\" => \"".$help_array_cif["file name"]."\", \"date\" => \"".$help_array_cif["date"]."\", \"input state\" => \"".$help_array_cif["input state"]."\"), ";
        }

        $data["next file number"] = $input_stream_stop;
        $data["input stream"] = $input_stream_files;

        return $data;
    }
}

// returns all building devices
if (!function_exists("getDevices"))
{
    function getDevices($current_building, $device_flag)
    {
        $building_devices = array();
        require("../test_data_file_devices/".$current_building.".php");

        // which device information is needed - name, or ID
        if ($device_flag == "NAME") {
            for ($i = 0; $i < count($building_devs); $i++)
                $building_devices[$i] = $building_devs["device ".$i]["name"];
        }
        else {
            for ($i = 0; $i < count($building_devs); $i++)
                $building_devices[$i] = $building_devs["device ".$i]["ID"];
        }

        return $building_devices;
    }
}

// returns the current needed building devices
if (!function_exists("getNeededDevices"))
{
    function getNeededDevices($current_building, $ci_file, $device_flag)
    {
        // reads the first line of the current inserting file (needed for the device comparison)
        $file = fopen("../test_data_files/".$current_building."/".$ci_file, "r");
        $first_line = fgets($file); // returns a string, of the current line, and has a size of 4 kB -> stores the address at the pointer $file for the next line (doesn't ignore NEW LINE)
        $help_line = substr($first_line, 0, -2); // deletes the last two string signs (in this case the NEW LINE)
        $first_line_array = explode(",", $help_line);
        fclose($file);

        $current_used_devices = array();
        $current_needed_devices = array();
        $device_index = 0;
        require("../test_data_file_devices/".$current_building.".php");

        // controls, which devices are needed for the insert process, of the current inserting file
        for ($i = 0; $i < count($building_devs); $i++) {
            $help_index = 1;

            while (($help_index < count($first_line_array)) && ($building_devs["device ".$i]["ID"] != $first_line_array[$help_index]))
                $help_index++;

            if ($help_index != count($first_line_array)) {
                $current_used_devices["device ".$device_index]["ID"] = $first_line_array[$help_index];
                $current_used_devices["device ".$device_index]["name"] = $building_devs["device ".$i]["name"];
                $device_index++;
            }
        }

        // which device information is needed - name, or ID
        if ($device_flag == "NAME") {
            for ($i = 0; $i < count($current_used_devices); $i++) {
                $current_needed_devices[$i] = $current_used_devices["device ".$i]["name"];
            }
        }
        else {
            for ($i = 0; $i < count($current_used_devices); $i++) {
                $current_needed_devices[$i] = $current_used_devices["device ".$i]["ID"];
            }
        }
        return $current_needed_devices;
    }
}

// checks, which days, of a specific building had been already used, and returns the unused
if (!function_exists("check_usedDays"))
{
    function check_usedDays($user, $building, $date)
    {
        require("../tmp_log_files/cif_".$user."_".$building.".php");
        $day_array = array();
        $count_of_days = date('t', strtotime($date));
        $month = date('m', strtotime($date));
        $year = date('y', strtotime($date));
        $current_date = " ";
        $offset = 1;

        for ($i = 1; $i <= $count_of_days; $i++) {
            if($i < 10)
                $current_date = "0".$i.".".$month.".".$year;
            else
                $current_date = $i.".".$month.".".$year;

            $j = 1;
            while (($j <= count($current_inputted_files)) && ($current_date != $current_inputted_files["file ".$j]["date"]))
                $j++;

            if(($j > count($current_inputted_files)) && ($i < 10)) {
                $day_array[$offset] = "0".$i;
                $offset++;
            }
            elseif($j > count($current_inputted_files)) {
                $day_array[$offset] = "".$i."";
                $offset++;
            }
        }

        return $day_array;
    }
}

// returns all days of a given month
if (!function_exists("get_allMonthDays"))
{
    function get_allMonthDays($current_timestamp)
    {
        $day_array = array();
        $count_of_days = date('t', $current_timestamp);

        for ($i = 1; $i <= $count_of_days; $i++) {
            if($i < 10)
                $day_array[$i] = "0".$i;
            else
                $day_array[$i] = "".$i."";
        }

        return $day_array;
    }
}

// Function for writing the .csv data files into the table consumptionevents of the data base
if (!function_exists("writingConsumptionevents")) {
    function writingConsumptionevents($connection, $user, $building, $data_directory, $data_filename, $current_line, $current_line_expected)
    {
        // the system inserts the energy sum of 240 data file lines, for all current needed devices, every time, this function is called
        $needed_data_lines = get_DataLines($current_line, $current_line_expected, $data_directory, $data_filename); // all current needed data lines are stored into an array
        $i = 0; // array index of needed_data_lines
        $current_devices = getNeededDevices($building, $data_filename, "ID");
        $cons_event_stream = "INSERT INTO consumptionevents (owner, device, start, duration, consumption) VALUES ";
        $current_con_event_array = get_ZeroLine(count($current_devices));
        $current_cir_event_array = array();

        // get beginning timestamp of consumptionevents
        require("../tmp_log_files/cif_".$user."_".$building.".php");
        $current_date = $current_inputted_files["file ".count($current_inputted_files)]["date"]; // current date, of the current inserting file
        $date_format = DateTime::createFromFormat('d.m.y H:i:s', $current_date.' 00:00:00'); // creates an instance of the DateTime-object, with a special format
        $current_date_timestamp = $date_format->getTimestamp() + $current_line;

        while ($i < count($needed_data_lines)) // computes also the circuit power of the last four minutes
        {
            $line_array = explode(",", $needed_data_lines[$i]); // splits the current energy data line into an array, at every comma
            $circuit_energy_help = 0; // circuit energy for every power event (means every second)

            // controls, if it's a data line, or only text
            if ($line_array[0] != "timestamp")
            {
                for ($k = 0; $k < count($current_devices); $k++)
                {
                    if ($line_array[$k + 1] != "NULL")
                    {
                        $conv_current_dev_energy = (float)$line_array[$k + 1]; // device energy in Watt
                        $current_con_event_array[$k] += $conv_current_dev_energy; // sums the consumptionevent energy for every device
                        $circuit_energy_help += $conv_current_dev_energy; // sums the circuit power for every second (= sum over all devices)
                    }
                }

                $circuit_energy_help = round($circuit_energy_help, 12); // current circuit power in W (rounded up to twelve decimal place)
            }

            $current_cir_event_array[$i][0] = $current_date_timestamp;
            $current_cir_event_array[$i][1] = $circuit_energy_help;

            $current_date_timestamp += 1;
            $i++;
        }

        // creates the consumption event stream
        for ($k = 0; $k < count($current_devices); $k++)
        {
            $current_dev_energy = round((($current_con_event_array[$k]) / 3600000), 14); // energy in kWh (1/3600 ... hour coefficient)
            $cons_event_stream .= "('$user', '".$current_devices[$k].substr($user, 0, 4)."', '$current_date_timestamp', '$i', '$current_dev_energy')";

            if($k == (count($current_devices) - 1))
                $cons_event_stream .= ";";
            else
                $cons_event_stream .= ", ";
        }

        $connection->addEventTDI($cons_event_stream); // inserts the current expected data lines into the data base (only one insert command)

        // refreshes the last entry file, of the current building, through the last inserted data line
        require("../tmp_log_files/le_".$user."_".$building.".php");
        $current_insert_key = $last_entry["insert key"];
        $last_insert_time = $last_entry["last insert time"];
        $input_stream_last_entry = "<?php \$last_entry = array(\"log-ID\" => \"" .$data_filename."\", \"user\" => \"".$user."\", \"current line\" => \"".($i + $current_line)."\", \"count of rows\" => \"".$last_entry["count of rows"]."\", \"insert key\" => \"".$current_insert_key."\", \"last insert time\" => \"".$last_insert_time."\"); ?>";
        writeFile("../tmp_log_files/","le_".$user."_".$building.".php", $input_stream_last_entry);

        // returns the energy consumption line, of the last 4 minutes (= 240 lines)
        $return_data_array = last_insertedLine($current_con_event_array);
        $next_data_array_index = count($return_data_array);
        $return_data_array[$next_data_array_index] = $i + $current_line; // current inserted line number
        $next_data_array_index++;
        $return_data_array[$next_data_array_index] = $current_date_timestamp; // timestamp of the last inserted consumptionevent

        // the whole energy consumption of the last consumption event, which will be used for the other events inside the data base (e.g. production, ...)
        $next_data_array_index++;
        $return_data_array[$next_data_array_index] = 0;
        for ($j = 0; $j < count($current_con_event_array); $j++)
            $return_data_array[$next_data_array_index] += $current_con_event_array[$j];

        $return_data_array[$next_data_array_index] = round(($return_data_array[$next_data_array_index] / 3600000), 14); // energy consumption in kWh

        // energy sum over all devices, for every data line (is needed for the circuit power / circuit average event)
        $next_data_array_index++;
        $return_data_array[$next_data_array_index] = get_ZeroMatrix(count($current_cir_event_array));
        for ($k = 0; $k < count($current_cir_event_array); $k++) {
            $return_data_array[$next_data_array_index][$k][0] += $current_cir_event_array[$k][0]; // timestamp
            $return_data_array[$next_data_array_index][$k][1] += $current_cir_event_array[$k][1]; // circuit power event
        }

        return $return_data_array;
    }
}

// returns the last inserted consumptionevent data line
if (!function_exists("last_insertedLine"))
{
    function last_insertedLine($lil_array)
    {
        $return_line_array = array();

        for ($j = 0; $j < count($lil_array); $j++)
            $return_line_array[$j] = round($lil_array[$j], 3);

        return $return_line_array;
    }
}

// returns a zero line
if (!function_exists("get_ZeroLine"))
{
    function get_ZeroLine($count_index)
    {
        $zero_line = array();

        for ($j = 0; $j < $count_index; $j++) {
            $zero_line[$j] = 0;
        }

        return $zero_line;
    }
}

// returns a zero array
if (!function_exists("get_ZeroMatrix"))
{
    function get_ZeroMatrix($count_index)
    {
        $zero_matrix = array();

        for ($j = 0; $j < $count_index; $j++) {
            $zero_matrix[$j][0] = 0;
            $zero_matrix[$j][1] = 0;
        }

        return $zero_matrix;
    }
}

// returns the current needed data lines, of the current inserting file
if (!function_exists("get_DataLines"))
{
    function get_DataLines($start_index, $end_index, $data_directory, $data_filename)
    {
        // stores all the data-file lines into the array $file -> the end of line sign will be also deleted
        $file = file($data_directory . $data_filename, FILE_IGNORE_NEW_LINES );
        $current_data_lines = array();
        $i = $start_index;

        while (($i < count($file)) && ($i < $end_index)) {
            $current_data_lines[$i - $start_index] = $file[$i];
            $i++;
        }

        return $current_data_lines;
    }
}

// This method can be extended anytime
// adds additional data events into the Mjölnir data base system, so that the most widgets are able to run with the test data
if (!function_exists("addingEvents"))
{
    function addingEvents($con, $building, $user, $table_name, $energy_data_prod = 0, $timestamp = 0, $energy_data_circuit = array())
    {
        switch ($table_name)
        {
            case "circuit_avg":
                $cir_id = $con->getCircuitID($user, $building);
                $current_hour = date("G", $energy_data_circuit[count($energy_data_circuit) - 1][0]);
                $current_minute = date("i", $energy_data_circuit[count($energy_data_circuit) - 1][0]);
                $min_max = array();
                $min_max = $con->getCircuitAvg($cir_id, $current_hour);
                $min = $min_max["min"];
                $max = $min_max["max"];
                
                // sets a new minimum start value, and the number of recorded days, if the current time is 00:00
                if(($current_hour == "0") && ($current_minute == "03")) {
                    $min = $energy_data_circuit[0][1];
                    $current_n = $con->getCirAvgRecDays($cir_id);
                    $new_cir_n = $current_n + 1;
                    $con->updateCirAvgRecDays($cir_id, $new_cir_n);
                }

                // sets the new min/max value
                for ($i = 0; $i < count($energy_data_circuit); $i++) {
                    if($max < $energy_data_circuit[$i][1])
                        $max = $energy_data_circuit[$i][1];
                    if($min > $energy_data_circuit[$i][1])
                        $min = $energy_data_circuit[$i][1];
                }

                $con->updateCirAvgMinMax($cir_id, $current_hour, $min, $max); // circuit average update
                break;
            case "circuit_power":
                $cir_power_event_stream = "INSERT INTO circuit_power (id, timestamp , power) VALUES ";
                $cir_id = $con->getCircuitID($user, $building);

                // creates the circuit power event stream
                for ($k = 0; $k < count($energy_data_circuit); $k++) {
                    $cir_power_event_stream .= "('$cir_id', ".$energy_data_circuit[$k][0].", ".$energy_data_circuit[$k][1].")";

                    if($k == (count($energy_data_circuit) - 1))
                        $cir_power_event_stream .= ";";
                    else
                        $cir_power_event_stream .= ", ";
                }

                $con->addCirPowerEventTDI($cir_power_event_stream);
                break;
            case "production":
                $current_date = date("d.m.y", $timestamp); // creates the date of the current used timestamp
                $date_format = DateTime::createFromFormat('d.m.y H:i:s', $current_date.' 00:00:00'); // creates an instance of the DateTime-object, with a special format
                $current_date_timestamp = $date_format->getTimestamp(); // timestamp of the current date at 00:00

                $existing_agg_cons_array = array();
                $existing_agg_cons_array = $con->getExistingAggCons($user, $current_date_timestamp);

                if ($existing_agg_cons_array[0] == "EXISTS") {
                    $existing_agg_cons_array[1] += $energy_data_prod;
                    $con->updateAggData($user, $current_date_timestamp, $existing_agg_cons_array[1]);
                    /*fwrite($file2, $existing_agg_cons_array[1]."\n");
                    fwrite($file2, $current_date."\n");*/
                }
                else
                    $con->addAggData($user, $current_date_timestamp, $energy_data_prod, 0);
                break;
        }
    }
}

if (!function_exists("checkInsertRights"))
{
    function checkInsertRights($user, $building)
    {
        $tmp_log_files = scandir("../tmp_log_files/");
        $count_of_tmp = count($tmp_log_files);
        $tmp_file_le_exists = check_existsFiles($tmp_log_files, $count_of_tmp, "le_".$user."_".$building.".php");

        if($tmp_file_le_exists == true) {
            require("../tmp_log_files/le_".$user."_".$building.".php");
            if($last_entry["insert key"] == "")
                return true;
            else {
                $last_insert_time = (int)$last_entry["last insert time"];
                $it_diff = time() - $last_insert_time;
                require("../tmp_log_files/cif_".$user."_".$building.".php");

                if (($it_diff > 60) && ($current_inputted_files["file ".count($current_inputted_files)]["input state"] != "BREAK"))
                    return true;
                if (($it_diff > 300) && ($current_inputted_files["file ".count($current_inputted_files)]["input state"] == "BREAK"))
                    return true;
                else return false;
            }
        }
        else return true;
    }
}
?>