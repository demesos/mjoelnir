<?php
    SESSION_START();

    // Including useful php-files with require method
    require_once("../../../core/php/methods.php");
    require_once("../../../userSettings.php");
    require_once("tdi_methods.php");
    require_once("../../../core/php/db.connect.php");

    /* Script - Start building */
    $user = $con->escape($_POST["user"]);
    $json = array();
    $data = array();
    $test_buildings_directory = "../test_data_files/";
    $test_buildings = scandir($test_buildings_directory);
    $count_of_test_buildings = count($test_buildings);

    if ($count_of_test_buildings > 2)
    {
        $data[0] = "BUILDING";
        $data[1] = $test_buildings;
        $data[2] = 2; // at which index the folder names really start
        $data[3] = $count_of_test_buildings;
    }
    else
    {
        $data[0] = "NO BUILDING";
        $data[1] = "No test building folders where founded in ../test_data_files/. This directory must be filled with building folders!";
    }

    $json["data"] = $data;
    echo json_encode($json); // sends the needed data back to the client (ajax request)