<?php
    SESSION_START();

    // Including useful php-files with require method
    require_once("../../../core/php/methods.php");
    require_once("../../../userSettings.php");
    require_once("tdi_methods.php");
    require_once("../../../core/php/db.connect.php");

    /* Script - Automatically stopped/Finished successful input process */
    $user = $con->escape($_POST["user"]);
    $building = $con->escape($_POST["building"]);
    $process_var = $con->escape($_POST["process_var"]);
    $input_stream_files = "";
    $json = array();
    $data = array();

    // refreshes the cif-file, of the current building, with the new current input state, and creates the return data lines
    require("../tmp_log_files/le_".$user."_".$building.".php");
    $isf_return_data = array();
    $isf_return_data = getCIFStream($user, $building, "LAST LINE");

    if ($process_var == "AUTOMATICALLY STOPPED") {
        $input_stream_files = $isf_return_data["input stream"]."\"file ".$isf_return_data["next file number"]."\" => array(\"file name\" => \"".$last_entry["log-ID"]."\", \"date\" => \"".$isf_return_data["next file date"]."\", \"input state\" => \"AUTOMATICALLY STOPPED\")); ?>";
        $data[0] = "Attention: The insert process has been automatically stopped, and will be closed in"; // info text, tdi-process view
        $data[1] = "5 seconds"; // count of seconds, the tdi-process view will be closed
        $data[2] = "The insert process of user ".$user.", ".$building." and test data file ".$last_entry["log-ID"]." has been automatically stopped!"; // info text, tdi-widget
    }
    else {
        $input_stream_files = $isf_return_data["input stream"]."\"file ".$isf_return_data["next file number"]."\" => array(\"file name\" => \"".$last_entry["log-ID"]."\", \"date\" => \"".$isf_return_data["next file date"]."\", \"input state\" => \"END\")); ?>";
        $data[0] = "Attention: The insert process has been successfully finished, and will be closed in"; // info text, tdi-process view
        $data[1] = "5 seconds"; // count of seconds, the tdi-process view will be closed
        $data[2] = "The insert process of user ".$user.", ".$building." and test data file ".$last_entry["log-ID"]." has been successfully finished!"; // info text, tdi-widget
    }

    writeFile("../tmp_log_files/","cif_".$user."_".$building.".php", $input_stream_files);
    $input_stream_last_entry = "<?php \$last_entry = array(\"log-ID\" => \"" .$last_entry["log-ID"]."\", \"user\" => \"".$user."\", \"current line\" => \"".$last_entry["current line"]."\", \"count of rows\" => \"".$last_entry["count of rows"]."\", \"insert key\" => \"\", \"last insert time\" => \"\"); ?>";
    writeFile("../tmp_log_files/","le_".$user."_".$building.".php", $input_stream_last_entry);

    $json["data"] = $data;
    echo json_encode($json); // sends the needed data back to the client (ajax request)
