<?php
    SESSION_START();

    // Including useful php-files with require method
    require_once("../../../core/php/methods.php");
    require_once("../../../userSettings.php");
    require_once("tdi_methods.php");
    require_once("../../../core/php/db.connect.php");

    /* Script - Input process */
    //$authkey = $con->escape($_POST["authkey"]);
    $user = $con->escape($_POST["user"]);
    $building = $con->escape($_POST["building"]);
    $current_row = (int)$con->escape($_POST["current_row"]);
    $current_row_expected = (int)$con->escape($_POST["current_row_expected"]);
    $json = array();
    $data = array();

    // the consumption events will be added to the Mjölnir data base
    require("../tmp_log_files/le_".$user."_".$building.".php");
    $help_consumption = array();
    $help_consumption = writingConsumptionevents($con, $user, $building, "../test_data_files/".$building."/", $last_entry["log-ID"], $current_row, $current_row_expected);

    // additional needed data events for the other used widgets (e.g. device_model, circuit_power, ...) will be added
    $events_table_names = array(0 => "circuit_avg", 1 => "circuit_power", 2 => "production");
    for($i = 0; $i < count($events_table_names); $i++)
        addingEvents($con, $building, $user, $events_table_names[$i], $help_consumption[count($help_consumption) - 2], $help_consumption[count($help_consumption) - 3], $help_consumption[count($help_consumption) - 1]);

    // data preparation, which will be sent back to the client
    for ($i = 0; $i < (count($help_consumption) - 4); $i++) // data of last inserted row
        $data[0][$i] = $help_consumption[$i];

    $data[1] = $help_consumption[count($help_consumption) - 4]; // current inserted row
    $data[2] = $help_consumption[count($help_consumption) - 3]; // timestamp of the last inserted consumptionevent

    $json["data"] = $data;
    echo json_encode($json); // sends the needed data back to the client (ajax request)