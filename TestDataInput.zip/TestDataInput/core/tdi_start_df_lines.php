<?php
    SESSION_START();

    // including useful php-files with require method (once checks, if this file had been included once before)
    require_once("../../../core/php/methods.php");
    require_once("../../../userSettings.php");
    require_once("tdi_methods.php");
    require_once("../../../core/php/db.connect.php");

    /* Script - Start data file lines */
    $building = $con->escape($_POST["building"]);
    $ci_file = $con->escape($_POST["ci_file"]);
    $last_insert_process = $con->escape($_POST["last_insert_process"]);
    $json = array();
    $data = array();

    if($last_insert_process == "STOP")
    {
        $user = $con->escape($_POST["user"]);
        require("../tmp_log_files/cif_".$user."_".$building.".php");
        require("../tmp_log_files/le_".$user."_".$building.".php");
        $data[0] = $last_entry["current line"];
        $data[1] = countOfLines("../test_data_files/".$building."/", $ci_file);
    }
    elseif ($last_insert_process == "AUTOMATICALLY STOPPED")
    {
        $user = $con->escape($_POST["user"]);
        require("../tmp_log_files/cif_".$user."_".$building.".php");
        require("../tmp_log_files/le_".$user."_".$building.".php");
        $data[0] = $last_entry["current line"];
        $data[1] = countOfLines("../test_data_files/".$building."/", $ci_file);
        $data[2] = "state: choose rows";
    }
    else
    {
        $data[0] = countOfLines("../test_data_files/".$building."/", $ci_file);
        $data[1] = "state: choose rows";
    }

    $json["data"] = $data;
    echo json_encode($json); // sends the needed data back to the client (ajax request)