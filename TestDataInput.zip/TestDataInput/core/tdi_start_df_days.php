<?php
    SESSION_START();

    // Including useful php-files with require method
    require_once("../../../core/php/methods.php");
    require_once("../../../userSettings.php");
    require_once("tdi_methods.php");
    require_once("../../../core/php/db.connect.php");

    /* Script - available data file days */
    $user = $con->escape($_POST["user"]);
    $building = $con->escape($_POST["building"]);
    $month_name = $con->escape($_POST["month_name"]);
    $data = array();
    $json = array();
    $tmp_log_directory = "../tmp_log_files/";
    $tmp_log_files = scandir($tmp_log_directory);
    $count_of_tmp = count($tmp_log_files);
    $current_month_days = array();

    // searching for the LastEntry and the CurrentInputted file of the current user, and building
    $tmp_file01_exists = check_existsFiles($tmp_log_files, $count_of_tmp, "cif_".$user."_".$building.".php");
    $tmp_file02_exists = check_existsFiles($tmp_log_files, $count_of_tmp, "le_".$user."_".$building.".php");

    if(($tmp_file01_exists == true) && ($tmp_file02_exists == true))
    {
        require($tmp_log_directory."cif_".$user."_".$building.".php");
        $last_date = $current_inputted_files["file ".count($current_inputted_files)]["date"];
        $date_format = DateTime::createFromFormat('d.m.y H:i:s', $last_date.' 00:00:00'); // creates an instance of the DateTime-object, with a special format
        $current_date_timestamp = $date_format->getTimestamp() + 100; // creates a timestamp of a given date
        $last_month_name = date('F', $current_date_timestamp); // stores the month name, of the given date

        // checks, if the month of the last inserted file is equal to the current month
        if($month_name == $last_month_name) {
            $data[0] = "EQUAL";
            $current_month_days = check_usedDays($user, $building, $last_date);
            for ($i = 0; $i < count($current_month_days); $i++)
                $data[1][$i] = $current_month_days[$i + 1];
            $data[2] = count($current_month_days);
            $data[3] = strtotime($last_date);
        }
        else {
            // deletes data base content, of the current building
            require("../test_data_file_devices/".$building.".php");
            $con->delSpecificTDIDataContent($user, $building, $building_devs);

            // deletes the temporary log files, of the current building and user
            if((file_exists($tmp_log_directory."le_".$user."_".$building.".php") && (file_exists($tmp_log_directory."cif_".$user."_".$building.".php")))) {
                unlink($tmp_log_directory."le_".$user."_".$building.".php");
                unlink($tmp_log_directory."cif_".$user."_".$building.".php");
            }

            $data[0] = "ALL DELETED";
            $current_month_days = get_allMonthDays(time());
            $data[1] = "All data base content, and temporary log-files of user ".$user." and ".$building.", have been deleted successfully, because they have been inserted last month!";

            for ($i = 0; $i < count($current_month_days); $i++)
                $data[2][$i] = $current_month_days[$i + 1];

            $data[3] = count($current_month_days);
        }
    }
    else
    {
        $data[0] = "NOT EXISTS";
        $current_month_days = get_allMonthDays(time());

        for ($i = 0; $i < count($current_month_days); $i++)
            $data[1][$i] = $current_month_days[$i + 1];

        $data[2] = count($current_month_days);
    }

    $json["data"] = $data;
    echo json_encode($json); // sends the needed data back to the client (ajax request)