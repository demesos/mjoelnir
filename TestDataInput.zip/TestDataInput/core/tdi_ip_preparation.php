<?php
    SESSION_START();

    // Including useful php-files with require method
    require_once("../../../core/php/methods.php");
    require_once("../../../userSettings.php");
    require_once("tdi_methods.php");
    require_once("../../../core/php/db.connect.php");

    /* Script - input process preparation */
    $user = $con->escape($_POST["user"]);
    $building = $con->escape($_POST["building"]);
    $current_insert_rights = checkInsertRights($user, $building);
    $json = array();
    $data = array();

    if ($current_insert_rights == true)
    {
        $process_var = $con->escape($_POST["process_var"]);
        $tmp_log_files = scandir("../tmp_log_files/");
        $count_of_tmp = count($tmp_log_files);

        // searching for the LastEntry and the CurrentInputted file of the current user, and building
        $tmp_file01_exists = check_existsFiles($tmp_log_files, $count_of_tmp, "cif_".$user."_".$building.".php");
        $tmp_file02_exists = check_existsFiles($tmp_log_files, $count_of_tmp, "le_".$user."_".$building.".php");

        $new_key_timestamp = microtime();
        $new_key = hash("sha256", $new_key_timestamp, false);

        if (($tmp_file01_exists == true) && ($tmp_file02_exists == true) && ($process_var == "BEGINNING")) {
            $data[0] = "FAILURE";
            $data[1] = "Failure: Multiple data of ".$building.", and user ".$user." have already been inserted!";
        }
        elseif (($tmp_file01_exists != true) && ($tmp_file02_exists != true) && ($process_var == "BEGINNING"))
        {
            $current_authkey = $con->getAuthkey($user);
            $current_inserting_file = $con->escape($_POST["ci_file"]);
            $count_of_rows = (int)$con->escape($_POST["count_of_rows"]);
            $selected_day = $con->escape($_POST["sel_day"]);

            require("../test_data_file_devices/".$building.".php");
            $building_devices = getDevices($building, "NAME");
            $needed_devices = getNeededDevices($building, $current_inserting_file, "NAME");
            insertingDevices($current_authkey, $con, $user, $building, "living room", "11", $building_devs);

            // creates the temporary log files, which are necessary for the input process of the current chosen building
            // streams of the inserted data files, and the last data entries
            $current_month = date('m');
            $current_year = date('y');
            $input_stream_files = "<?php \$current_inputted_files = array(\"file 1\" => array(\"file name\" => \"" .$current_inserting_file."\", \"date\" => \"".$selected_day.".".$current_month.".".$current_year."\", \"input state\" => \"NEXT LINES\")); ?>";
            $input_stream_last_entry = "<?php \$last_entry = array(\"log-ID\" => \"" .$current_inserting_file."\", \"user\" => \"".$user."\", \"current line\" => \"0\", \"count of rows\" => \"".$count_of_rows."\", \"insert key\" => \"".$new_key."\", \"last insert time\" => \"".time()."\"); ?>";
            writeFile("../tmp_log_files/","cif_".$user."_".$building.".php", $input_stream_files);
            writeFile("../tmp_log_files/","le_".$user."_".$building.".php", $input_stream_last_entry);

            $data[0] = "NEXT LINES"; // next input process state
            $data[1] = "Following devices for user ".$user.", ".$building." and test data file ".$current_inserting_file." have been inserted:";
            $data[2] = $building_devices;
            $data[3] = $needed_devices;
            $data[4] = $new_key; // through this key, an insert process can be started
        }
        else
        {
            if (($tmp_file01_exists == true) && ($tmp_file02_exists == true) && ($process_var == "CONTINUE AT FILE"))
            {
                $current_inserting_file = $con->escape($_POST["ci_file"]);
                require("../tmp_log_files/cif_".$user."_".$building.".php");
                $inserted_files = array();
                $inserted_files = get_inputtedFiles($current_inputted_files);
                $file_inserted = check_inputtedFiles($inserted_files, $current_inserting_file);

                if ($file_inserted == false) 
                {
                    $count_of_rows = (int)$con->escape($_POST["count_of_rows"]);
                    $selected_day = $con->escape($_POST["sel_day"]);

                    // overwrites the file cif_...building ....php
                    $isf_return_data = array();
                    $isf_return_data = getCIFStream($user, $building, "FILE");
                    $current_month = date('m');
                    $current_year = date('y');
                    $input_stream_files = $isf_return_data["input stream"]."\"file ".$isf_return_data["next file number"]."\" => array(\"file name\" => \"".$current_inserting_file."\", \"date\" => \"".$selected_day.".".$current_month.".".$current_year."\", \"input state\" => \"NEXT LINES\")); ?>"; // new line
                    writeFile("../tmp_log_files/","cif_".$user."_".$building.".php", $input_stream_files);

                    // overwrites the file le_...building ....php
                    $input_stream_last_entry = "<?php \$last_entry = array(\"log-ID\" => \"" .$current_inserting_file."\", \"user\" => \"".$user."\", \"current line\" => \"0\", \"count of rows\" => \"".$count_of_rows."\", \"insert key\" => \"".$new_key."\", \"last insert time\" => \"".time()."\"); ?>";
                    writeFile("../tmp_log_files/","le_".$user."_".$building.".php", $input_stream_last_entry);

                    // current devices for the tdi-simulation
                    $current_devices = array();
                    $current_devices = getNeededDevices($building, $current_inserting_file, "NAME");

                    $data[0] = "NEXT LINES"; // next input process state
                    $data[1] = "The insert process for user ".$user.", ".$building." and test data file ".$current_inserting_file." will be started in";
                    $data[2] = $current_devices;
                    $data[3] = $new_key; // through this key, an insert process can be started
                }
                else {
                    $data[0] = "FAILURE";
                    $data[1] = "Failure: The insert process of ".$current_inserting_file." for ".$building.", and user ".$user." have already been finished!";
                }
            }
            elseif (($tmp_file01_exists == true) && ($tmp_file02_exists == true) && ($process_var == "CONTINUE AT LINE"))
            {
                $last_insert_process = $con->escape($_POST["last_insert_process"]);
                require("../tmp_log_files/le_".$user."_".$building.".php");

                // overwrites the file cif_building ....php
                $isf_return_data = array();
                $isf_return_data = getCIFStream($user, $building, "LINE");
                $input_stream_files = $isf_return_data["input stream"]."\"file ".$isf_return_data["next file number"]."\" => array(\"file name\" => \"".$last_entry["log-ID"]."\", \"date\" => \"".$isf_return_data["next file date"]."\", \"input state\" => \"NEXT LINES\")); ?>";
                writeFile("../tmp_log_files/","cif_".$user."_".$building.".php", $input_stream_files);

                $current_devices = array();
                $current_devices = getNeededDevices($building, $last_entry["log-ID"], "NAME");

                $data_text = "Nothing";
                $new_count_of_rows = "Nothing";

                if($last_insert_process == "AUTOMATICALLY STOPPED")
                {
                    // overwrites the file le_building ....php
                    $new_count_of_rows = $con->escape($_POST["count_of_rows"]);
                    $input_stream_last_entry = "<?php \$last_entry = array(\"log-ID\" => \"" .$last_entry["log-ID"]."\", \"user\" => \"".$user."\", \"current line\" => \"".$last_entry["current line"]."\", \"count of rows\" => \"".$new_count_of_rows."\", \"insert key\" => \"".$new_key."\", \"last insert time\" => \"".time()."\"); ?>";
                    writeFile("../tmp_log_files/","le_".$user."_".$building.".php", $input_stream_last_entry);

                    $data_text = "The automatically stopped insert process of user ".$user.", ".$building." and test data file ".$last_entry["log-ID"]." will be continued in";
                }
                else
                {
                    $new_count_of_rows = $last_entry["count of rows"];
                    $input_stream_last_entry = "<?php \$last_entry = array(\"log-ID\" => \"" .$last_entry["log-ID"]."\", \"user\" => \"".$user."\", \"current line\" => \"".$last_entry["current line"]."\", \"count of rows\" => \"".$new_count_of_rows."\", \"insert key\" => \"".$new_key."\", \"last insert time\" => \"".time()."\"); ?>";
                    writeFile("../tmp_log_files/","le_".$user."_".$building.".php", $input_stream_last_entry);
                    $data_text = "The stopped insert process of user ".$user.", ".$building." and test data file ".$last_entry["log-ID"]." will be continued in";
                }

                $data[0] = "NEXT LINES"; // next input process state
                $data[1] = $data_text;
                $data[2] = $last_entry["current line"];
                $data[3] = $new_count_of_rows;
                $data[4] = $current_devices;
                $data[5] = $new_key; // through this key, an insert process can be started
            }
            else {
                $data[0] = "FAILURE";
                $data[1] = "Failure: All data of ".$building.", and user ".$user." have already been deleted!";
            }
        }
    }
    else {
        $data[0] = "NO IP POSSIBLE";
        $data[1] = "Sorry! No insert process for ".$building." can be started at the moment! Try it in few minutes again!";
    }

$json["data"] = $data;
echo json_encode($json); // sends the needed data back to the client (ajax request)