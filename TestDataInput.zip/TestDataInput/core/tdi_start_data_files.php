<?php
    SESSION_START();

    // including useful php-files with require method (once checks, if this file had been included once before)
    require_once("../../../core/php/methods.php");
    require_once("../../../userSettings.php");
    require_once("tdi_methods.php");
    require_once("../../../core/php/db.connect.php");

    /* Script - Start data files */
    $user = $con->escape($_POST["user"]);
    $building = $con->escape($_POST["building"]);
    $json = array();
    $data = array();
    $tmp_log_files_directory = "../tmp_log_files/";
    $tmp_log_files = scandir($tmp_log_files_directory);
    $count_of_tmp = count($tmp_log_files);
    $test_data_files_directory = "../test_data_files/".$building."/";
    $test_data_files = scandir($test_data_files_directory);

    // searching for the LastEntry and the CurrentInputted file of the current user, and building
    $tmp_file01_exists = check_existsFiles($tmp_log_files, $count_of_tmp, "cif_".$user."_".$building.".php");
    $tmp_file02_exists = check_existsFiles($tmp_log_files, $count_of_tmp, "le_".$user."_".$building.".php");

    // checks, if both files are existing
    if(($tmp_file01_exists == true) && ($tmp_file02_exists == true))
    {
        require($tmp_log_files_directory."cif_".$user."_".$building.".php"); // includes this file every time, require is called
        $count_of_cif = count($current_inputted_files);
        $last_file_index = "file ".$count_of_cif;
        $last_file_input_state = $current_inputted_files[$last_file_index]["input state"];

        // if the input process of the last inputted data file is already finished
        if($last_file_input_state == "END")
        {
            // prepares the data, which will be sended back to the client
            if(count($test_data_files) > 2)
            {
                $current_inputted_data_files = get_inputtedFiles($current_inputted_files); // get back an array of the current inputted files
                $test_data_files_rest = array();
                $tdfr_index = 0; // current index of the not inputted test data files
                $tdf_index = 0;

                // fills the $test_data_files_rest array with the test data files, which aren't already inserted into the Mjoelnir data base
                while ($tdf_index < count($test_data_files))
                {
                    $help_current_file = $test_data_files[$tdf_index];
                    $checked = check_inputtedFiles($current_inputted_data_files, $help_current_file);

                    if($checked == true)
                    {
                        $test_data_files_rest[$tdfr_index] = $help_current_file;
                        $tdfr_index++;
                        $tdf_index++;
                    }
                    else
                        $tdf_index++;
                }

                if(count($test_data_files_rest) > 2) {
                    $data[0] = "NOT ALL";
                    $data[1] = $test_data_files_rest;
                    $data[2] = 2;
                    $data[3] = count($test_data_files_rest);
                    $data[4] = $last_file_input_state;
                    $data[5] = $con->getTestBuildingsCount($user, $building); // returns the count of test-buildings (n ... count; -1 ... nothing)
                }
                else {
                    $data[0] = "ALL DATA INSERTED";
                    $data[1] = "All test data files have been already inserted! If there are more existing, you have to load them into ../test_data_files/".$building."/! Otherwise, delete all the test data for ".$building." through the trash-button!";
                }
            }
            else
            {
                $data[0] = "NO DATA";
                $data[1] = "No test data files for user ".$user." and ".$building." have been founded! You must load them into ../test_data_files/".$building."/!";
            }
        }
        else
        {
            if(count($test_data_files) > 2)
            {
                require($tmp_log_files_directory."le_".$user."_".$building.".php");
                $data[0] = $last_file_input_state; // should be STOP, or AUTOMATICALLY STOPPED
                $data[1][0] = $last_entry["log-ID"];
                $data[1][1] = $last_entry["user"];
                $data[1][2] = $last_entry["current line"];

                if(($last_file_input_state == "STOP") || ($last_file_input_state == "NEXT LINES") || ($last_file_input_state == "BREAK")) {
                    $data[2] = "The last insert process of user ".$user." and ".$building." has been stopped at the following test data file:";
                    $data[3] = $last_entry["count of rows"];
                    $data[4] = countOfLines("../test_data_files/".$building."/", $last_entry["log-ID"]);
                }
                else
                    $data[2] = "The last insert process of user ".$user." and ".$building." has been automatically stopped at the following test data file:";    
            }
            else
            {
                $data[0] = "NO DATA";
                $data[1] = "No test data files for user ".$user." and ".$building." have been founded! You must load them into ../test_data_files/".$building."/!";
            }
        }
    }
    else
    {
        require("../test_data_file_devices/".$building.".php");
        $con->delSpecificTDIDataContent($user, $building, $building_devs); // deletes all test data content for the current user and building

        // prepares the data, which the server sends back to the client
        if(count($test_data_files) > 2)
        {
            $data[0] = "ALL";
            $data[1] = $test_data_files;
            $data[2] = 2;
            $data[3] = count($test_data_files);
            $data[4] = "NO TEMP FILES";
            $data[5] = $con->getTestBuildingsCount($user, $building);
        }
        else
        {
            $data[0] = "NO DATA";
            $data[1] = "No test data files for user ".$user." and ".$building." have been founded! You must load them into ../test_data_files/".$building."/!";
        }
    }

    $json["data"] = $data;
    echo json_encode($json); // sends the needed data back to the client (ajax request)