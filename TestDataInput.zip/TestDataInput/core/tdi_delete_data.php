<?php
    SESSION_START();

    // Including useful php-files with require method
    require_once("../../../core/php/methods.php");
    require_once("../../../userSettings.php");
    require_once("tdi_methods.php");
    require_once("../../../core/php/db.connect.php");

    /* Script - Delete data and log-files */
    $user = $con->escape($_POST["user"]);
    $building = $con->escape($_POST["building"]);
    $json = array();
    $data = array();
    $tmp_log_directory = "../tmp_log_files/";

    // deletes data base content, of the current building
    require("../test_data_file_devices/".$building.".php");
    $con->delSpecificTDIDataContent($user, $building, $building_devs);

    // deletes the temporary log files, of the current building
    if((file_exists($tmp_log_directory."le_".$user."_".$building.".php") && (file_exists($tmp_log_directory."cif_".$user."_".$building.".php")))) {
        unlink($tmp_log_directory."le_".$user."_".$building.".php");
        unlink($tmp_log_directory."cif_".$user."_".$building.".php");
    }

    $data[0] = "All data base content, and temporary log-files of user ".$user." and ".$building.", have been deleted successfully!";
    $json["data"] = $data;
    echo json_encode($json); // sends the needed data back to the client (ajax request)