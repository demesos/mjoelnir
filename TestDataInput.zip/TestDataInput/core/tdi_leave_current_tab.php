<?php
    SESSION_START();

    // Including useful php-files with require method
    require_once("../../../core/php/methods.php");
    require_once("../../../userSettings.php");
    require_once("tdi_methods.php");
    require_once("../../../core/php/db.connect.php");

    /* Script - Leave current tab */
    $user_insert_key = $con->escape($_POST["insert_key"]);
    $user = $con->escape($_POST["user"]);
    $building = $con->escape($_POST["building"]);
    $interrupt_method = $con->escape($_POST["interrupt_method"]);
    $json = array();
    $data = array();

    // overwrites the file le_...building ....php; deletes the insert key, and the last insert time; sets the current input state of the cif-file on STOP
    require("../tmp_log_files/le_".$user."_".$building.".php");

    if($user_insert_key == $last_entry["insert key"]) {
        if($interrupt_method == "STOP BY HARD") {
            $isf_return_data = array();
            $isf_return_data = getCIFStream($user, $building, "LINE");
            $input_stream_files = $isf_return_data["input stream"]."\"file ".$isf_return_data["next file number"]."\" => array(\"file name\" => \"".$last_entry["log-ID"]."\", \"date\" => \"".$isf_return_data["next file date"]."\", \"input state\" => \"STOP\")); ?>";
            writeFile("../tmp_log_files/","cif_".$user."_".$building.".php", $input_stream_files);
        }
        $current_inserting_file = $last_entry["log-ID"];
        $current_line = $last_entry["current line"];
        $count_of_rows = $last_entry["count of rows"];
        $input_stream_last_entry = "<?php \$last_entry = array(\"log-ID\" => \"" .$current_inserting_file."\", \"user\" => \"".$user."\", \"current line\" => \"".$current_line."\", \"count of rows\" => \"".$count_of_rows."\", \"insert key\" => \"\", \"last insert time\" => \"\"); ?>";
        writeFile("../tmp_log_files/","le_".$user."_".$building.".php", $input_stream_last_entry);

        $data[0] = "KEY DELETED";
        $data[1] = "The insert process key has been deleted successfully!";
    }
    else {
        $data[0] = "KEY NOT DELETED";
        $data[1] = "Failure: The user insert key, and the insert process key are not equal!";
    }

    $json["data"] = $data;
    echo json_encode($json); // sends the needed data back to the client (ajax request)