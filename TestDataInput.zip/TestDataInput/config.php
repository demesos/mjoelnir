<?php 
$config = array(
	"ID" => "TDI-WASCHER",
	"title" => "Test-Data Input",
	"path" => "TestDataInput",
	"size" => "1x1",
    "inputPos" => "disaggregated"
	);
$configDefault = array(
	"path" => $config["path"],
	"inputCur" => "disaggregated"
	);
?>