<style type="text/css">
    /** Widget style **/
    /* label styles */
    /* header information label */
    .tdi-header p {
        position: absolute;
        top: 0%;
        left: 148px;
        height: 15%;
        text-align: left;
        font-size: 20px;
        color: #fcf75e;
    }

    /* standard information/data labels - general */
    .tdi-information p, .tdi-data p, .tdi-information-ip-prep p, .tdi-data-ip-prep p {
        position: absolute;
        height: 12%;
        text-align: left;
        font-size: 16px;
        font-weight: bold;
    }

    /* standard information/data labels - specific */
    .tdi-information p, .tdi-data p {
        width: 60%;
    }

    /* button style */
    /* general */
    .tdi-button input[type=button] {
        position: absolute;
        top: 65%;
        width: 15%;
        box-sizing: border-box;
        border: 2px solid yellow;
        border-radius: 4px;
        font-size: 18px;
        background-color: black;
        padding: 12px 0px 12px 0px;
        color: white;
    }

    @media all and (max-width: 1536px) {
        .tdi-button input[type=button] { font-size: 17px; }
    }

    /** select box style **/
    /* drop-down-box; used for buildings, data files and rows - general */
    .tdi-select-box select {
        position: absolute;
        left: 20%;
        width: 60%;
        height: 10%;
        border-radius: 4px;
        border: grey 2px solid;
        box-shadow: 2px 2px 5px 1px rgba(0, 0, 0, 0.3);
        cursor: pointer;
        padding-left: 10px;
        font-family: Arial;
        font-size: 16px;
        color: black;
    }

    /* drop-down-box; used for buildings, data files and rows - specific */
    .tdi-select-box select:active {
        border-color: #0000bf;
    }

    /** unsorted list style **/
    .tdi-unsorted-list ul {
        position: absolute;
        top: 35%; /*// = 35%*/
        left: 20%;
    }

    .tdi-unsorted-list li {
        font-size: 15px;
        font-family: Arial;
        color: yellow;
    }

    /** Input process dialog style **/
    /* transparent div */
    .tdi-input-process-transparent, .tdi-trash-process-transparent {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.75); /* sets the background black transparent */
    }

    /* main view */
    .tdi-input-process-main-view {
        position: absolute;
        left: 27.5%;
        top: 25%;
        width: 50%;
        height: 50%;
        border-radius: 6px;
        border: yellow 2px solid;
        background: rgb(71, 71, 71); /* rgb(...) sets the background color */
    }

    @media all and (max-width: 1366px) {
        .tdi-input-process-main-view { left: 15%; width: 70%; }
    }

    @media all and (max-width: 800px) {
        .tdi-input-process-main-view { top: 35%; left: 5%; width: 90%; height: 30%; }
    }

    /* title line */
    .tdi-input-process-title-line, .tdi-trash-process-title-line {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
        background: rgb(0, 0, 0);
    }

    @media all and (max-width: 1920px) {
        .tdi-input-process-title-line { height:7.25%; }
    }

    @media all and (max-width: 1536px) {
        .tdi-input-process-title-line { height:7.75%; }
    }

    @media all and (max-width: 1366px) {
        .tdi-input-process-title-line { height:8.5%; }
    }

    @media all and (max-width: 800px) {
        .tdi-input-process-title-line { height:8.25%; }
    }

    /* title line text */
    .tdi-input-process-title-line p, .tdi-trash-process-title-line p {
        font-family: Arial;
        font-size: 22px;
        color: yellow;
        padding-top: 1px;
        padding-left: 8px;
    }

    /* info text */
    .tdi-input-process-text p {
        position: absolute;
        top: 15%;
        width: 25%;
        height: 12%;
        text-align: left;
        font-size: 16px;
        font-weight: bold;
    }

    .tdi-input-process-infotext p {
        position: absolute;
        top: 13%;
        left: 55%;
        width: 40%;
        height: 35px;
        text-align: left;
        font-size: 12px;
        font-weight: bold;
    }

    .tdi-input-process-infotext-counter p {
        position: absolute;
        top: 16.75%;
        left: 81%;
        width: 10%;
        height: 35px;
        text-align: left;
        font-size: 12px;
        font-weight: bold;
        color: yellow;
    }

    /* last line table div */
    .tdi-input-process-table {
        position: absolute;
        left: 2.5%;
        top: 28%;
        width: 95%;
        height: 30%;
        background: transparent;
    }

    /* rectangular - used for tdi-input-process simulation */
    .tdi-input-process-outer-rectangular {
        position: absolute;
        top: 60%;
        width: 80%;
        left: 10%;
        height: 30px;
        border-radius: 4px;
        border: white 1px solid;
    }

    .tdi-input-process-inner-rectangular {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 4px;
        border: green 1px solid;
        background-color: green;
    }

    .tdi-input-process-inner-rectangular-text p {
        position: absolute;
        left: 72.5%;
        top: 3px;
        width: 25%;
        height: 24px;
        text-align: right;
        font-size: 16px;
        font-weight: bold;
        color: white;
    }

    /* button-style - used for break, continue and stop (input process); used for Yes, No and OK (trash process) */
    .tdi-input-process-button input[type=button], .tdi-trash-process-button input[type=button] {
        position: absolute;
        box-sizing: border-box;
        border: 2px solid yellow;
        border-radius: 4px;
        font-size: 16px;
        color: white;
        background-color: black;
        padding: 10px 0px 10px 0px;
    }

    /** Trash process dialog style (classes transparent, title-line, and button are equal to the classes of Input process dialog style) **/
    /* main view */
    .tdi-trash-process-main-view {
        position: absolute;
        left: 37.5%;
        top: 32.5%;
        width: 25%;
        height: 30%;
        border-radius: 6px;
        border: yellow 2px solid;
        background: rgb(71, 71, 71); /* rgb(...) sets the background color */
    }

    /* height of title line */
    .tdi-trash-process-title-line {
        height: 12%;
    }

    /* detail view */
    .tdi-trash-process-detail-view {
        position: absolute;
        left: 5%;
        top: 15%;
        width: 90%;
        height: 80%;
    }

    /* info text */
    .tdi-trash-process-text p {
        position: absolute;
        top: 10%;
        height: 30%;
        text-align: left;
        font-size: 14px;
        font-weight: bold;
    }

    @media all and (min-width: 1920px) {
        .tdi-trash-process-text p { font-size: 17px; left: 15%; width: 70%; }
    }

    @media all and (min-width: 1536px) and (min-width: 1366px) {
        .tdi-trash-process-text p { left: 15%; width: 70%; }
    }

    @media all and (max-width: 1366px) {
        .tdi-trash-process-text p { left: 12.5%; width: 75%; }
    }

    @media all and (max-width: 800px) {
        .tdi-trash-process-main-view {
            left: 25%;
            top: 37.5%;
            width: 50%;
            height: 25%;
        }
        .tdi-trash-process-text p { font-size: 17px; left: 15%; width: 70%; }
    }
</style>

<script type="text/javascript"> // will be executed every page reload

    var window_width, window_height, current_screen, res_xml, id, widget_id, cell, cell_id, user, current_key, current_privilege, box, current_state, process_var, process_var_help;
    var element_id, timer_index, help_array_devices, st_as_fs_text;
    var current_timer_id_counter, current_timer_id_ip, last_insert_process, current_length_pb, current_pc_pb, current_file_ip;
    var current_count_of_rows, whole_count_of_rows, current_row, current_row_expected, trash_process_using, active_insert_tab;
    id = dashboard.widgets[dashboard.widgetCur][0];
    widget_id = id; // is needed, because if the function nextWidget() will be called, the variable id will be initialized with the last inserted widget-id
    cell = dashboard.widgetCur;
    cell_id = cell; // is needed, because if the function nextWidget() will be called, the variable cell will be initialized with the last inserted cell-id
    user = dashboard.user;
    current_key = $("#tab_authkey").text();
    current_privilege = "0";
    process_var = "BEGINNING"; // symbolizes the current test data input process state
    timer_index = 5; // start index for the timerIP function
    help_array_devices = new Array();
    current_length_pb = 0; // current length, of the insert process progress bar
    current_pc_pb = 0; // current per cent, of the inputted lines
    current_count_of_rows = 0; // count of rows, the system has to insert
    whole_count_of_rows = 0; // whole count of rows, the data file consists of
    current_row = 0; // last inserted row
    current_row_expected = 0; // until which data file row, the system should insert at the next insert step
    window_width = $(window).innerWidth(); // returns the current inner width, of the browser window
    window_height = $(window).innerHeight(); // returns the current inner height, of the browser window
    current_screen_res = getScreenResolution(); // stores the current used screen size
    trash_process_using = "DATA NEEDED"; // how the trash process should be deleted
    active_insert_tab = false;

    // Set a new div (=widget) at the end, or after the last inserted widget
    $("#cell" + cell_id).append('<div id="test_data_input' + widget_id + '" class="widget_inner" style="overflow:auto;"></div>');

    // searching for the current user privilege (A ... admin; L ... default user)
    $.ajax ({
        type: "POST",
        url: "widgets/TestDataInput/core/tdi_start_get_key.php",
        data: "key=" + current_key,
        success: function (data) {
            var object, data_array;
            object = JSON.parse(data);
            data_array = object.data;
            current_privilege = data_array[1];

            if ((current_privilege == "A") && (current_screen_res != "OTHER RES")) { // only admins are able to use this widget
                // actually the tables, device_model, occupancy and analytics, every time this widget is reloaded
                $.ajax ({
                    type: "POST",
                    url: "core/php/cron.deviceModel.php",
                    success: function (data) {
                        console.log(data);

                        $.ajax ({
                            type: "POST",
                            url: "core/php/cron.occupancy.php",
                            success: function (data) {
                                console.log(data);

                                $.ajax ({
                                    type: "POST",
                                    url: "core/php/cron.analytics.php",
                                    success: function (data) {
                                        console.log(data);
                                    }
                                });
                            }
                        });
                    }
                });

                console.log(current_screen_res);
                reloadTDIWidget();
            }
            else if ((current_privilege == "A") && (current_screen_res == "OTHER RES")) {
                box = '<div class="tdi-information"><p id="tdi_information' + widget_id + '">The current window resolution cannot be used for this widget! You must change the resolution and reload this page!</p></div>';
                $("#test_data_input" + widget_id).html(box);
                $("#tdi_information" + widget_id).css({top: 10 + '%'});
                $("#tdi_information" + widget_id).css({left: 20 + '%'});
                $("#tdi_information" + widget_id).css({color: "#ffffff"});
            }
            else {
                box = '<div class="tdi-information"><p id="tdi_information' + widget_id + '">This widget can be only used by the Mjölnir-Administrator!</p></div>';
                $("#test_data_input" + widget_id).html(box);
                $("#tdi_information" + widget_id).css({top: 10 + '%'});
                $("#tdi_information" + widget_id).css({left: 20 + '%'});
                $("#tdi_information" + widget_id).css({color: "#ffffff"});
            }

            dashboard.nextWidget(); // sets the current widget as last inserted widget
        }
    });

    // loads and reloads this widget
    function reloadTDIWidget() {
        $.ajax // starts a post-ajax-request
        ({
            type: "POST",
            url: "widgets/TestDataInput/core/tdi_start_users.php",
            data: "user=" + user,
            success: function (data) // the success-event will be initialized with a function (like an object)
            {
                var object, data_array;
                object = JSON.parse(data);
                data_array = object.data;

                if (data_array[0] == "USERS") {
                    current_state = "state: choose users"; // next click-state

                    // html-content, which has to be added to this widget
                    box = '<div class="tdi-information"><p id="tdi_information_users' + widget_id + '">Select a user!</p></div>'
                        + '<div class="tdi-select-box"><select id="tdi_select_users' + widget_id + '"><option value="0" selected>' + data_array[1][0] + '</option></select></div>' // dropdown list buildings
                        + '<div class="tdi-button"><input id="tdi_button_back' + widget_id + '" type="button" value="Back"></div>'
                        + '<div class="tdi-button"><input id="tdi_button_next' + widget_id + '" type="button" value="Next"></div>';
                    $("#test_data_input" + widget_id).html(box); // inserts a new content into the choosed widget
                    fillingDropDownList("#tdi_select_users", 1, data_array[2], data_array[1]);

                    // additional css-style
                    $("#tdi_information_users" + widget_id).css({top: 10 + '%'});
                    $("#tdi_information_users" + widget_id).css({left: 20 + '%'});
                    $("#tdi_information_users" + widget_id).css({color: "#ffffff"});
                    $("#tdi_select_users" + widget_id).css({top: 25 + '%'});
                    $("#tdi_button_back" + widget_id).css({left: 32.5 + '%'});
                    $("#tdi_button_back" + widget_id).css({backgroundColor: "#9d9d9d"});
                    $("#tdi_button_next" + widget_id).css({left: 52.5 + '%'});

                    // additional html-element-activations
                    $("#tdi_button_back" + widget_id).attr("disabled", true); // disables the back button

                    // event initialization
                    hover_leaveEvent("tdi_button_back", "880000", "0000bf", "000000", "ffff00");
                    hover_leaveEvent("tdi_button_next", "2B7CE9", "0000bf", "000000", "ffff00");

                    $("#tdi_button_next" + widget_id).unbind("click");
                    $("#tdi_button_next" + widget_id).on({
                        click: function () {
                            btnNext()
                        }
                    });
                    $("#tdi_button_back" + widget_id).unbind("click");
                    $("#tdi_button_back" + widget_id).on({
                        click: function () {
                            btnBack()
                        }
                    });
                } else {
                    // html-content, which has to be added to this widget
                    box = '<div class="tdi-information"><p id="tdi_information' + widget_id + '">' + data_array[1] + '</p></div>'
                        + '<div class="tdi-button"><input id="tdi_button_retry' + widget_id + '" type="button" value="Retry"></div>';
                    $("#test_data_input" + widget_id).html(box);

                    // additional css-style
                    $("#tdi_information" + widget_id).css({top: 10 + '%'});
                    $("#tdi_information" + widget_id).css({left: 20 + '%'});
                    $("#tdi_information" + widget_id).css({color: "#ffffff"});
                    $("#tdi_button_retry" + widget_id).css({left: 42.5 + '%'});

                    // event initialization
                    hover_leaveEvent("tdi_button_retry", "9d9d9d", "0000bf", "000000", "ffff00");
                    $("#tdi_button_retry" + widget_id).unbind("click");
                    $("#tdi_button_retry" + widget_id).on({
                        click: function () {
                            $("#test_data_input" + widget_id).empty(); // removes all content, inside the div-element test_data_input+widget_id
                            dashboard.getData();
                        }
                    });
                }
            }
        });
    }

    // fills a dropdown list with additional content
    function fillingDropDownList(curr_drop_down_list, start_index, end_index, input_array) {
        for (var i = start_index; i < end_index; i++)
            $(curr_drop_down_list + widget_id).append('<option value="' + i + '">' + input_array[i] + '</option>');
    }

    // initializes hover- and leave-events to wished content
    function hover_leaveEvent(content_id, hover_backgroundColor, hover_borderColor, leave_backgroundColor, leave_borderColor) {
        $("#" + content_id + widget_id).unbind("hover");
        $("#" + content_id + widget_id).hover(function () // enters, if the mouse is be arranged inside the current button (initializes the hover-event of the current button)
        {
            if ($("#" + content_id + widget_id).attr("disabled") != "disabled") {
                $("#" + content_id + widget_id).css({backgroundColor: "#" + hover_backgroundColor});
                $("#" + content_id + widget_id).css({borderColor: "#" + hover_borderColor});
            }
        });

        $("#" + content_id + widget_id).unbind("mouseleave");
        $("#" + content_id + widget_id).mouseleave(function () // enters, if the mouse leaves the current button (initializes the mouseleave-event of the current button)
        {
            if ($("#" + content_id + widget_id).attr("disabled") != "disabled") {
                $("#" + content_id + widget_id).css({backgroundColor: "#" + leave_backgroundColor});
                $("#" + content_id + widget_id).css({borderColor: "#" + leave_borderColor});
            }
        });
    }

    // returns the current used screen resolution (e.g. 1920x1080, ...)
    function getScreenResolution() {
        if ((window_width > 1536) && (window_width <= 1920))
            return "1920x1080";
        else if ((window_width > 1366) && (window_width <= 1536))
            return "1536x1000";
        else if ((window_width > 1159) && (window_width <= 1366))
            return "1366x768";
        else if ((window_width > 700) && (window_width <= 800))
            return "800x1200";
        else
            return "OTHER RES";
    }

    function setCSSValues(tag_name, start_index, end_index) {
        for (var i = start_index; i < end_index; i = i + 2) {
            var coordinate_desc = res_xml.getElementsByTagName(tag_name)[0].children[i].textContent;
            var tag_id = res_xml.getElementsByTagName(tag_name)[0].getAttribute("id");
            var css_value = res_xml.getElementsByTagName(tag_name)[0].children[i + 1].textContent;

                switch (coordinate_desc) {
                    case "top":
                        $("#" + tag_id + widget_id).css({top: parseFloat(css_value) + '%'});
                        break;
                    case "left":
                        $("#" + tag_id + widget_id).css({left: parseFloat(css_value) + '%'});
                        break;
                    case "width":
                        $("#" + tag_id + widget_id).css({width: parseFloat(css_value) + '%'});
                        break;
                    case "height":
                        $("#" + tag_id + widget_id).css({height: parseFloat(css_value) + '%'});
                        break;
                }
        }
    }

    function setActiveResValues(current_res_object) {
        var curr_indention = current_res_object["indention"];

        switch (curr_indention) {
                    case "top":
                        $("#" + current_res_object["tag_id"] + widget_id).css({top: current_res_object["value_" + current_screen_res] + '%'});
                        break;
                    case "left":
                        $("#" + current_res_object["tag_id"] + widget_id).css({left: current_res_object["value_" + current_screen_res] + '%'});
                        break;
                    case "width":
                        $("#" + current_res_object["tag_id"] + widget_id).css({width: current_res_object["value_" + current_screen_res] + '%'});
                        break;
                    case "height":
                        $("#" + current_res_object["tag_id"] + widget_id).css({height: current_res_object["value_" + current_screen_res] + '%'});
                        break;
                    case "font-size":
                        $("#" + current_res_object["tag_id"] + widget_id).css({fontSize: current_res_object["value_" + current_screen_res] + 'px'});
                        break;
        }
    }

    /** Test-Data-Input-Process **/
    // functions, btnNext and btnBack, are used to control the common widget process
    function btnNext() 
    {
        var selectedUser = $("#tdi_select_users" + widget_id).find(':selected').text(); // returns the text of the selected dropdown list element
        var selectedBuilding = "";
        window_width = $(window).innerWidth();
        current_screen_res = getScreenResolution();

        if (current_state != "state: choose users")
            selectedBuilding = $("#tdi_select_building" + widget_id).find(':selected').text();

        switch (current_state) {
            case "state: choose users":
                $.ajax // starts a post-ajax-request
                ({
                    type: "POST",
                    url: "widgets/TestDataInput/core/tdi_start_building.php",
                    data: "user=" + user,
                    success: function (data) { // the success-event will be initialized with a function (like an object)
                        var object, data_array;
                        object = JSON.parse(data);
                        data_array = object.data;

                        if (data_array[0] == "BUILDING") {
                            current_state = "state: choose building"; // next click-state

                            // html-content, which has to be added to this widget
                            box = '<div class="tdi-information" id="tdi_information_building_div' + widget_id + '"><p id="tdi_information_building' + widget_id + '">Select a test building!</p></div>'
                                + '<div class="tdi-select-box" id="tdi_select_building_div' + widget_id + '"><select id="tdi_select_building' + widget_id + '"><option value="' + data_array[2] + '" selected>' + data_array[1][data_array[2]] + '</option></select></div>'; // dropdown list buildings
                            $("#test_data_input" + widget_id).append(box); // inserts a new content into the chosen widget
                            $("#cell" + cell_id + "header").append('<div class="tdi-header" id="tdi_user_header_div' + widget_id + '"><p id="tdi_user_header' + widget_id + '">for ' + selectedUser + '</p></div>');
                            fillingDropDownList("#tdi_select_building", (data_array[2] + 1), data_array[3], data_array[1]);

                            // additional css-style
                            $("#tdi_information_building" + widget_id).css({top: 10 + '%'});
                            $("#tdi_information_building" + widget_id).css({left: 20 + '%'});
                            $("#tdi_information_building" + widget_id).css({color: "#ffffff"});
                            $("#tdi_select_building" + widget_id).css({top: 25 + '%'});
                            $("#tdi_button_back" + widget_id).css({backgroundColor: "#000000"});

                            // additional html-element-activations
                            $("#tdi_button_back" + widget_id).attr("disabled", false); // enables the back button
                            $("#tdi_information_users" + widget_id).hide(); // hides label tdi_information_building
                            $("#tdi_select_users" + widget_id).hide();
                        } else {
                            // html-content, which has to be added to this widget
                            box = '<div class="tdi-information"><p id="tdi_information' + widget_id + '">' + data_array[1] + '</p></div>'
                                + '<div class="tdi-button"><input id="tdi_button_retry' + widget_id + '" type="button" value="Retry"></div>';
                            $("#test_data_input" + widget_id).append(box);
                            $("#cell" + cell_id + "header").append('<div class="tdi-header" id="tdi_user_header_div' + widget_id + '"><p id="tdi_user_header' + widget_id + '">for ' + selectedUser + '</p></div>');

                            // additional css-style
                            $("#tdi_information" + widget_id).css({top: 10 + '%'});
                            $("#tdi_information" + widget_id).css({left: 20 + '%'});
                            $("#tdi_information" + widget_id).css({color: "#ffffff"});
                            $("#tdi_button_retry" + widget_id).css({left: 42.5 + '%'});

                            // additional html-element-activations
                            $("#tdi_button_back" + widget_id).hide();
                            $("#tdi_button_next" + widget_id).hide();
                            $("#tdi_information_users" + widget_id).hide(); // hides label tdi_information_building
                            $("#tdi_select_users" + widget_id).hide();

                            // event initialization
                            hover_leaveEvent("tdi_button_retry", "9d9d9d", "0000bf", "000000", "ffff00");
                            $("#tdi_button_retry" + widget_id).unbind("click");
                            $("#tdi_button_retry" + widget_id).on({
                                click: function () {
                                    $("#test_data_input" + widget_id).empty(); // removes all content, inside the div-element test_data_input+widget_id
                                    dashboard.getData();
                                }
                            });
                        }
                    }
                });
                break;
            case "state: choose building":
                $.ajax // starts a new post-ajax-request
                ({
                    type: "POST",
                    url: "widgets/TestDataInput/core/tdi_start_data_files.php",
                    data: "user=" + selectedUser + "&building=" + selectedBuilding,
                    success: function (data) // the success-event will be initialized with a function (like an object)
                    {
                        var object, data_array;
                        object = JSON.parse(data);
                        data_array = object.data;

                        // if the input process starts at a new file;
                        // all, or not all data-files can be shown in the drop-down-list
                        if ((data_array[0] == "ALL") || (data_array[0] == "NOT ALL")) {
                            current_state = "state: choose file"; // next click-state
                            last_insert_process = data_array[4]; // at which insert-process-state Mjölnir had stopped last time

                            if (data_array[0] == "NOT ALL") {
                                process_var = "CONTINUE AT FILE"; // current input-process-state
                                process_var_help = process_var; // represents a buffer (will be needed, if the insert process ends)
                            } else {
                                process_var = "BEGINNING"; // current input-process-state
                                process_var_help = process_var;
                            }

                            // html-content, which has to be added to this widget
                            box = '<div class="tdi-information" id="tdi_information_file_div' + widget_id + '"><p id="tdi_information_file' + widget_id + '">Select a test data input file</p></div>'
                                + '<div class="tdi-data" id="tdi_data_file_div' + widget_id + '"><p id="tdi_data_file' + widget_id + '">for ' + selectedBuilding + '!</p></div>'
                                + '<div class="tdi-select-box" id="tdi_select_data_file_div' + widget_id + '"><select id="tdi_select_data_file' + widget_id + '"><option value="' + data_array[2] + '" selected>' + data_array[1][data_array[2]] + '</option></select></div>' // dropdown list data files
                                + '<div class="tdi-button" id="tdi_button_trash_div' + widget_id + '"><input id="tdi_button_trash' + widget_id + '" type="button" value="Trash"></div>';
                            $("#test_data_input" + widget_id).append(box); // expands the content of the choosed widget
                            fillingDropDownList("#tdi_select_data_file", (data_array[2] + 1), data_array[3], data_array[1]);

                            // additional css-style
                            $("#tdi_information_file" + widget_id).css({top: 10 + '%'});
                            var cur_res_object_left = {tag_id:"tdi_information_file", indention:"left", value_1920x1080:20, value_1536x1000:20, value_1366x768:15, value_800x1200:20};
                            var cur_res_object_width = {tag_id:"tdi_information_file", indention:"width", value_1920x1080:60, value_1536x1000:60, value_1366x768:70, value_800x1200:60};
                            setActiveResValues(cur_res_object_left);
                            setActiveResValues(cur_res_object_width);
                            $("#tdi_information_file" + widget_id).css({color: "#ffffff"});
                            $("#tdi_data_file" + widget_id).css({top: 18.5 + '%'});
                            var cur_res_object_02_left = {tag_id:"tdi_data_file", indention:"left", value_1920x1080:20, value_1536x1000:20, value_1366x768:15, value_800x1200:20};
                            setActiveResValues(cur_res_object_02_left);
                            $("#tdi_data_file" + widget_id).css({color: "#ffff00"});
                            var cur_res_object_03_left = {tag_id:"tdi_select_data_file", indention:"left", value_1366x768:15};
                            var cur_res_object_03_width = {tag_id:"tdi_select_data_file", indention:"width", value_1366x768:70};
                            setActiveResValues(cur_res_object_03_left);
                            setActiveResValues(cur_res_object_03_width);
                            $("#tdi_select_data_file" + widget_id).css({top: 30 + '%'});
                            $("#tdi_button_back" + widget_id).css({backgroundColor: "#000000"});
                            $("#tdi_button_back" + widget_id).css({left: 22.5 + '%'});
                            $("#tdi_button_next" + widget_id).css({left: 42.5 + '%'});
                            $("#tdi_button_trash" + widget_id).css({left: 62.5 + '%'});

                            // additional html-element-activations
                            $("#tdi_information_building" + widget_id).hide(); // hides label tdi_information_building
                            $("#tdi_select_building" + widget_id).hide();

                            if (data_array[5] == -1) {
                                $("#tdi_button_trash" + widget_id).attr("disabled", true);
                                $("#tdi_button_trash" + widget_id).css({backgroundColor: "#9d9d9d"});
                            }

                            // event initialization
                            hover_leaveEvent("tdi_button_trash", "F03030", "0000bf", "000000", "ffff00");
                            $("#tdi_button_trash" + widget_id).unbind("click");
                            $("#tdi_button_trash" + widget_id).on({
                                click: function () {
                                    trash_process_using = "NEEDED DATA";
                                    drawTrashProcess();
                                }
                            });
                        } else if (data_array[0] == "NO DATA") { // should be expand through test data input dialog
                            // html-content, which has to be added to this widget
                            box = '<div class="tdi-information"><p id="tdi_information' + widget_id + '">' + data_array[1] + '</p></div>'
                                + '<div class="tdi-button"><input id="tdi_retry' + widget_id + '" type="button" value="Retry"></div>';
                            $("#test_data_input" + widget_id).append(box);

                            // additional css-style
                            $("#tdi_information" + widget_id).css({top: 10 + '%'});
                            var cur_res_object_left = {tag_id:"tdi_information", indention:"left", value_1920x1080:20, value_1536x1000:20, value_1366x768:15, value_800x1200:20 };
                            var cur_res_object_width = {tag_id:"tdi_information", indention:"width", value_1366x768:70 };
                            setActiveResValues(cur_res_object_left);
                            setActiveResValues(cur_res_object_width);
                            $("#tdi_information" + widget_id).css({color: "#ffffff"});
                            $("#tdi_retry" + widget_id).css({left: 42.5 + '%'});

                            // additional html-element-activations
                            $("#tdi_button_back" + widget_id).hide();
                            $("#tdi_button_next" + widget_id).hide();
                            $("#tdi_information_building" + widget_id).hide();
                            $("#tdi_select_building" + widget_id).hide();

                            // event initialization
                            hover_leaveEvent("tdi_retry", "9d9d9d", "0000bf", "000000", "ffff00");
                            $("#tdi_retry" + widget_id).unbind("click"); // unbind the click event, of the current button
                            $("#tdi_retry" + widget_id).on({
                                click: function () { // initializes the button click event with the function getData(), of the js-class dashboard
                                    $("#test_data_input" + widget_id).empty();
                                    dashboard.getData();
                                }
                            });
                        } else if (data_array[0] == "ALL DATA INSERTED") {
                            // html-content, which has to be added to this widget
                            box = '<div class="tdi-information"><p id="tdi_information' + widget_id + '">' + data_array[1] + '</p></div>'
                                + '<div class="tdi-button"><input id="tdi_trash' + widget_id + '" type="button" value="Trash"></div>'
                                + '<div class="tdi-button"><input id="tdi_retry' + widget_id + '" type="button" value="Retry"></div>';
                            $("#test_data_input" + widget_id).append(box);

                            // additional css-style
                            $("#tdi_information" + widget_id).css({top: 10 + '%'});
                            var cur_res_object_left = {tag_id:"tdi_information", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20 };
                            var cur_res_object_width = {tag_id:"tdi_information", indention:"width", value_1536x1000:70, value_1366x768:80 };
                            var cur_res_object_fs = {tag_id:"tdi_information", indention:"font-size", value_1366x768:15 };
                            setActiveResValues(cur_res_object_left);
                            setActiveResValues(cur_res_object_width);
                            setActiveResValues(cur_res_object_fs);
                            $("#tdi_information" + widget_id).css({color: "#ffffff"});
                            $("#tdi_trash" + widget_id).css({left: 32.5 + '%'});
                            $("#tdi_retry" + widget_id).css({left: 52.5 + '%'});

                            // additional html-element-activations
                            $("#tdi_button_back" + widget_id).hide();
                            $("#tdi_button_next" + widget_id).hide();
                            $("#tdi_information_building" + widget_id).hide();
                            $("#tdi_select_building" + widget_id).hide();

                            // event initialization
                            hover_leaveEvent("tdi_trash", "F03030", "0000bf", "000000", "ffff00");
                            $("#tdi_trash" + widget_id).unbind("click"); // unbind the click event, of the current button
                            $("#tdi_trash" + widget_id).on({
                                click: function () { // initializes the button click event with the function getData(), of the js-class dashboard
                                    drawTrashProcess();
                                }
                            });

                            hover_leaveEvent("tdi_retry", "9d9d9d", "0000bf", "000000", "ffff00");
                            $("#tdi_retry" + widget_id).unbind("click"); // unbind the click event, of the current button
                            $("#tdi_retry" + widget_id).on({
                                click: function () { // initializes the button click event with the function getData(), of the js-class dashboard
                                    $("#test_data_input" + widget_id).empty();
                                    dashboard.getData();
                                }
                            });
                        } else {
                            process_var = "CONTINUE AT LINE"; // current input-process-state
                            process_var_help = process_var;
                            last_insert_process = data_array[0];

                            // html-content, which has to be added to this widget
                            box = '<div class="tdi-information" id="tdi_information_stopped_div' + widget_id + '"><p id="tdi_information_stopped' + widget_id + '">' + data_array[2] + '</p></div>'
                                + '<div class="tdi-unsorted-list" id="tdi_lif_' + widget_id + '"><ul id="tdi_lif_ul_' + widget_id + '">'
                                + '<li id="tdi_lif_log_id_' + widget_id + '">Log-ID: ' + data_array[1][0] + '</li>'
                                + '<li id="tdi_lif_user_' + widget_id + '">User: ' + data_array[1][1] + '</li>'
                                + '<li id="tdi_lif_cl_' + widget_id + '" value="' + data_array[1][2] + '">Current hour: ' + Math.round(data_array[1][2] / 3600) + '</li>'
                                + '</ul></div>';
                            $("#test_data_input" + widget_id).append(box);

                            // additional css-style, and current_state
                            if (last_insert_process == "AUTOMATICALLY STOPPED") {
                                current_state = "state: choose day of current month"; // next click-state
                                $("#tdi_information_stopped" + widget_id).css({top: 4 + '%'});
                            }
                            else { // if last_insert_process == STOP
                                current_state = "state: start at line"; // next click-state
                                current_count_of_rows = parseInt(data_array[3]);
                                whole_count_of_rows = parseInt(data_array[4]);
                                $("#tdi_information_stopped" + widget_id).css({top: 5 + '%'});
                            }

                            $("#tdi_information_stopped" + widget_id).css({color: "#ffffff"});
                            $("#tdi_button_back" + widget_id).css({backgroundColor: "#000000"});

                            // additional css-style for the current used screen format
                            var cur_res_object_left = {tag_id:"tdi_information_stopped", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20};
                            var cur_res_object_width = {tag_id:"tdi_information_stopped", indention:"width", value_1920x1080:60, value_1536x1000:70, value_1366x768:80, value_800x1200:60};
                            var cur_res_object_fs = {tag_id:"tdi_information_stopped", indention:"font-size", value_1536x1000:15, value_1366x768:14};
                            var cur_res_object_02_left = {tag_id:"tdi_lif_ul_", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20};
                            var cur_res_object_02_fs = {tag_id:"tdi_lif_ul_", indention:"font-size", value_1536x1000:14, value_1366x768:13};

                            setActiveResValues(cur_res_object_left);
                            setActiveResValues(cur_res_object_width);
                            setActiveResValues(cur_res_object_fs);
                            setActiveResValues(cur_res_object_02_left);
                            setActiveResValues(cur_res_object_02_fs);

                            // additional html-element-activations
                            $("#tdi_information_building" + widget_id).hide();
                            $("#tdi_select_building" + widget_id).hide();
                            $("#tdi_button_back" + widget_id).attr("disabled", false);

                            // controls, which month had been used for the last insert process
                            var today = new Date(); // declares, and initializeses a date object
                            var month_name = today.toLocaleString('default', { month: 'long' }); // returns the month name, of the date object

                            $.ajax
                            ({
                                type: "POST",
                                url: "widgets/TestDataInput/core/tdi_start_df_days.php",
                                data: "user=" + selectedUser + "&building=" + selectedBuilding + "&month_name=" + month_name,
                                success: function (data) {
                                    var object, data_array;
                                    object = JSON.parse(data);
                                    data_array = object.data;

                                    // if all data of the previous month, of the selected user, and building had been deleted
                                    if(data_array[0] == "ALL DELETED") {
                                        trash_process_using = "NEEDED DATA";
                                        drawTrashProcess();

                                        // additional html-element-activations
                                        $("#tdi_trash_process_information" + widget_id).hide();
                                        $("#tdi_trash_process_yes" + widget_id).hide();
                                        $("#tdi_trash_process_no" + widget_id).hide();
                                        $("#tdi_trash_process_commit_text" + widget_id).text(data_array[1]); // additional css-style (?????)
                                        $("#tdi_trash_process_commit_text" + widget_id).show();
                                        $("#tdi_trash_process_ok" + widget_id).show();
                                    }
                                }
                            });
                        }
                    }
                });
                break;

            case "state: choose file":
                var selectedDataFile = $("#tdi_select_data_file" + widget_id).find(':selected').text();
            	var today = new Date(); // declares, and initializese a date object
				var month_name = today.toLocaleString('default', { month: 'long' }); // returns the month name, of the date object

                // html-content, which has to be added to this widget
                box = '<div class="tdi-information" id="tdi_information_days_div' + widget_id + '"><p id="tdi_information_days' + widget_id + '">Select an insert process day for</p></div>'
                    + '<div class="tdi-data" id="tdi_data_days_div' + widget_id + '"><p id="tdi_data_days' + widget_id + '">' + selectedUser + ', ' + selectedBuilding + ', and ' + selectedDataFile + '</p></div>'
                    + '<div class="tdi-information" id="tdi_information_days_2_div' + widget_id + '"><p id="tdi_information_days_2' + widget_id + '">of month ' + month_name + '!</p></div>'
                    + '<div class="tdi-select-box" id="tdi_select_days_div' + widget_id + '"><select id="tdi_select_days' + widget_id + '"></select></div>';
                $("#test_data_input" + widget_id).append(box);

                $.ajax
                ({
                    type: "POST",
                    url: "widgets/TestDataInput/core/tdi_start_df_days.php",
                    data: "user=" + selectedUser + "&building=" + selectedBuilding + "&month_name=" + month_name,
                    success: function (data) {
                        var object, data_array;
                        object = JSON.parse(data);
                        data_array = object.data;
                        current_state = "state: choose day of current month"; // next click-state

                        // if all data of the previous month, of the selected user, and building had been deleted
                        if(data_array[0] == "ALL DELETED") {
                            fillingDropDownList("#tdi_select_days", 0, data_array[3], data_array[2]); // html-content, which has to be added to this widget

                            trash_process_using = "NO DATA NEEDED";
                            drawTrashProcess();

                            // additional html-element-activations
                            $("#tdi_trash_process_information" + widget_id).hide();
                            $("#tdi_trash_process_yes" + widget_id).hide();
                            $("#tdi_trash_process_no" + widget_id).hide();
                            $("#tdi_trash_process_commit_text" + widget_id).text(data_array[1]); // additional css-style (?????)
                            $("#tdi_trash_process_commit_text" + widget_id).show();
                            $("#tdi_trash_process_ok" + widget_id).show();
                        }
                        else 
                            fillingDropDownList("#tdi_select_days", 0, data_array[2], data_array[1]); // html-content, which has to be added to this widget

                        // additional css-style (muss noch einmal überprüft werden)
                        $("#tdi_information_days" + widget_id).css({top: 10 + '%'});
                        var cur_res_object_left = {tag_id:"tdi_information_days", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20};
                        var cur_res_object_width = {tag_id:"tdi_information_days", indention:"width", value_1920x1080:60, value_1536x1000:70, value_1366x768:80, value_800x1200:60};
                        setActiveResValues(cur_res_object_left);
                        setActiveResValues(cur_res_object_width);
                        $("#tdi_information_days" + widget_id).css({color: "#ffffff"});
                        $("#tdi_information_days_2" + widget_id).css({top: 35 + '%'});
                        var cur_res_object_01_left = {tag_id:"tdi_information_days_2", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20};
                        var cur_res_object_01_width = {tag_id:"tdi_information_days_2", indention:"width", value_1920x1080:60, value_1536x1000:70, value_1366x768:80, value_800x1200:60};
                        setActiveResValues(cur_res_object_01_left);
                        setActiveResValues(cur_res_object_01_width);
                        $("#tdi_information_days_2" + widget_id).css({color: "#ffffff"});
                        $("#tdi_data_days" + widget_id).css({top: 18.5 + '%'});
                        var cur_res_object_02_left = {tag_id:"tdi_data_days", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20};
                        var cur_res_object_02_width = {tag_id:"tdi_data_days", indention:"width", value_1536x1000:70, value_1366x768:80};
                        setActiveResValues(cur_res_object_02_left);
                        setActiveResValues(cur_res_object_02_width);
                        $("#tdi_data_days" + widget_id).css({color: "#ffff00"});
                        $("#tdi_select_days" + widget_id).css({top: 45 + '%'});
                        var cur_res_object_03_left = {tag_id:"tdi_select_days", indention:"left", value_1536x1000:15, value_1366x768:10};
                        var cur_res_object_03_width = {tag_id:"tdi_select_days", indention:"width", value_1536x1000:70, value_1366x768:80};
                        setActiveResValues(cur_res_object_03_left);
                        setActiveResValues(cur_res_object_03_width);
                        $("#tdi_button_back" + widget_id).css({left: 32.5 + '%'});
                        $("#tdi_button_next" + widget_id).css({left: 52.5 + '%'});

                        // additional html-element-activations
                        $("#tdi_information_file" + widget_id).hide();
                        $("#tdi_data_file" + widget_id).hide();
                        $("#tdi_select_data_file" + widget_id).hide();
                        $("#tdi_button_trash" + widget_id).hide();
                    }
                });
            	break;

            case "state: choose day of current month":
                var object, data_array, line_counter, hour_counter;

                // html-content, which has to be added to this widget
                box = '<div class="tdi-information" id="tdi_information_rows_div' + widget_id + '"><p id="tdi_information_rows' + widget_id + '">How many hours of</p></div>'
                    + '<div class="tdi-data" id="tdi_data_rows_2_div' + widget_id + '"><p id="tdi_data_rows_2' + widget_id + '">for ' + selectedBuilding + '</p></div>'
                    + '<div class="tdi-information" id="tdi_information_rows_2_div' + widget_id + '"><p id="tdi_information_rows_2' + widget_id + '">should be inserted?</p></div>'
                    + '<div class="tdi-select-box" id="tdi_select_rows_div' + widget_id + '"><select id="tdi_select_rows' + widget_id + '"></select></div>';
                $("#test_data_input" + widget_id).append(box);

                if (last_insert_process == "AUTOMATICALLY STOPPED") {
                    var log_id = $("#tdi_lif_log_id_" + widget_id).text();
                    var log_id_array = log_id.split(" "); // get last inserted data file

                    $.ajax
                    ({
                        type: "POST",
                        url: "widgets/TestDataInput/core/tdi_start_df_lines.php",
                        data: "user=" + selectedUser + "&building=" + selectedBuilding + "&ci_file=" + log_id_array[1] + "&last_insert_process=" + last_insert_process,
                        success: function (data) {
                            object = JSON.parse(data);
                            data_array = object.data;
                            current_state = data_array[2]; // next click-state ("state: choose rows")
                            whole_count_of_rows = parseInt(data_array[1]);
                            line_counter = parseInt(data_array[0]) + 3600;
                            hour_counter = Math.round(line_counter / 3600);

                            // html-content, which has to be added to this widget
                            $("#test_data_input" + widget_id).append('<div class="tdi-data" id="tdi_data_rows_div' + widget_id + '"><p id="tdi_data_rows_1' + widget_id + '">' + log_id_array[1] + '</p></div>');
                            selectRowsContent("#tdi_select_rows", line_counter, hour_counter, data_array[1]);

                            // additional css-style
                            $("#tdi_data_rows_1" + widget_id).css({top: 18.5 + '%'});
                            $("#tdi_data_rows_1" + widget_id).css({left: 20 + '%'});
                            $("#tdi_data_rows_1" + widget_id).css({color: "#ffff00"});

                            // additional html-element-activations
                            $("#tdi_information_stopped" + widget_id).hide();
                            $("#tdi_lif_" + widget_id).hide();
                        }
                    });
                } else {
                    var selectedDataFile = $("#tdi_select_data_file" + widget_id).find(':selected').text();

                    $.ajax
                    ({
                        type: "POST",
                        url: "widgets/TestDataInput/core/tdi_start_df_lines.php",
                        data: "building=" + selectedBuilding + "&ci_file=" + selectedDataFile + "&last_insert_process=" + last_insert_process,
                        success: function (data) {
                            object = JSON.parse(data);
                            data_array = object.data;
                            current_state = data_array[1]; // next click-state ("state: choose rows")
                            whole_count_of_rows = parseInt(data_array[0]);
                            line_counter = 3600;
                            hour_counter = 1;

                            // html-content, which has to be added to this widget
                            $("#test_data_input" + widget_id).append('<div class="tdi-data" id="tdi_data_rows_div' + widget_id + '"><p id="tdi_data_rows_1' + widget_id + '">' + selectedDataFile + '</p></div>');
                            selectRowsContent("#tdi_select_rows", line_counter, hour_counter, data_array[0]);

                            // additional css-style
                            $("#tdi_data_rows_1" + widget_id).css({top: 18.5 + '%'});
                            $("#tdi_data_rows_1" + widget_id).css({left: 20 + '%'});
                            $("#tdi_data_rows_1" + widget_id).css({color: "#ffff00"});
                            $("#tdi_button_back" + widget_id).css({left: 32.5 + '%'});
                            $("#tdi_button_next" + widget_id).css({left: 52.5 + '%'});

                            // additional html-element-activations
                            $("#tdi_information_days" + widget_id).hide();
                            $("#tdi_data_days" + widget_id).hide();
                            $("#tdi_information_days_2" + widget_id).hide();
                            $("#tdi_select_days" + widget_id).hide();
                        }
                    });
                }

                // additional css-style
                $("#tdi_information_rows" + widget_id).css({top: 10 + '%'});
                $("#tdi_information_rows" + widget_id).css({left: 20 + '%'});
                $("#tdi_information_rows" + widget_id).css({color: "#ffffff"});
                $("#tdi_data_rows_2" + widget_id).css({top: 27 + '%'});
                $("#tdi_data_rows_2" + widget_id).css({left: 20 + '%'});
                $("#tdi_data_rows_2" + widget_id).css({color: "#ffff00"});
                $("#tdi_information_rows_2" + widget_id).css({top: 35.5 + '%'});
                $("#tdi_information_rows_2" + widget_id).css({left: 20 + '%'});
                $("#tdi_information_rows_2" + widget_id).css({color: "#ffffff"});
                $("#tdi_select_rows" + widget_id).css({top: 48 + '%'});
                break;

            case "state: choose rows":
                var selectedRows_hours = $("#tdi_select_rows" + widget_id).find(':selected').text();
                var selectedRows = $("#tdi_select_rows" + widget_id).find(':selected').val();
                current_count_of_rows = parseInt(selectedRows);

                // html-content, which has to be added to this widget
                box = '<div class="tdi-information" id="tdi_information_selected_div' + widget_id + '"><p id="tdi_information_selected' + widget_id + '">Selected file:</p></div>'
                    + '<div class="tdi-information" id="tdi_information_selected_2_div' + widget_id + '"><p id="tdi_information_selected_2' + widget_id + '">Count of hours:</p></div>'
                    + '<div class="tdi-data" id="tdi_data_selected_2_div' + widget_id + '"><p id="tdi_data_selected_2' + widget_id + '">' + selectedRows_hours + '</p></div>';

                if (last_insert_process == "AUTOMATICALLY STOPPED") {
                    var log_id = $("#tdi_lif_log_id_" + widget_id).text();
                    var log_id_array = log_id.split(" ");
                    current_state = "state: start at line"; // next click-state
                    box = box + '<div class="tdi-data" id="tdi_data_selected_div' + widget_id + '"><p id="tdi_data_selected' + widget_id + '">' + log_id_array[1] + ' for ' + selectedBuilding + '</p></div>';
                } else {
                    var selectedDataFile = $("#tdi_select_data_file" + widget_id).find(':selected').text();
                    current_state = "state: start"; // next click-state
                    box = box + '<div class="tdi-data" id="tdi_data_selected_div' + widget_id + '"><p id="tdi_data_selected' + widget_id + '">' + selectedDataFile + ' for ' + selectedBuilding + '</p></div>';
                }

                $("#test_data_input" + widget_id).append(box);

                // additional css-style
                $("#tdi_information_selected" + widget_id).css({top: 10 + '%'});
                $("#tdi_information_selected" + widget_id).css({color: "#ffffff"});
                $("#tdi_data_selected" + widget_id).css({top: 10 + '%'});
                $("#tdi_data_selected" + widget_id).css({width: 50 + '%'});
                $("#tdi_data_selected" + widget_id).css({color: "#ffff00"});
                $("#tdi_information_selected_2" + widget_id).css({top: 27 + '%'});
                $("#tdi_information_selected_2" + widget_id).css({color: "#ffffff"});
                $("#tdi_data_selected_2" + widget_id).css({top: 27 + '%'});
                $("#tdi_data_selected_2" + widget_id).css({width: 50 + '%'});
                $("#tdi_data_selected_2" + widget_id).css({color: "#ffff00"});

                // additional css-style for the current used screen format
                var cur_res_object_left = {tag_id:"tdi_data_selected", indention:"left", value_1920x1080:40, value_1536x1000:42.5, value_1366x768:45, value_800x1200:40};
                var cur_res_object_02_left = {tag_id:"tdi_data_selected_2", indention:"left", value_1920x1080:40, value_1536x1000:42.5, value_1366x768:45, value_800x1200:40};
                var cur_res_object_03_left = {tag_id:"tdi_information_selected", indention:"left", value_1920x1080:10, value_1536x1000:5, value_1366x768:5, value_800x1200:10};
                var cur_res_object_04_left = {tag_id:"tdi_information_selected_2", indention:"left", value_1920x1080:10, value_1536x1000:5, value_1366x768:5, value_800x1200:10};

                setActiveResValues(cur_res_object_left);
                setActiveResValues(cur_res_object_02_left);
                setActiveResValues(cur_res_object_03_left);
                setActiveResValues(cur_res_object_04_left);

                // additional html-element-activations
                $("#tdi_information_rows" + widget_id).hide();
                $("#tdi_data_rows_1" + widget_id).hide();
                $("#tdi_data_rows_2" + widget_id).hide();
                $("#tdi_information_rows_2" + widget_id).hide();
                $("#tdi_select_rows" + widget_id).hide();
                break;

            case "state: start":
                $("#cell" + cell_id + "remove").hide(); // hides the remove button, of the current widget
                insertProcessPreparation(); // enters the test data input process
                break;

            case "state: start at line":
                $("#cell" + cell_id + "remove").hide();
                insertProcessPreparation();
                break;
        }
    }

    function btnBack() {
        switch (current_state) {
            case "state: choose building":
                current_state = "state: choose users"; // previous click-state

                // additional css-style
                $("#tdi_button_back" + widget_id).css({backgroundColor: "#9d9d9d"});
                $("#tdi_button_back" + widget_id).css({borderColor: "#ffff00"});

                // additional html-element-activations
                $("#tdi_user_header_div" + widget_id).remove();
                $("#tdi_information_building_div" + widget_id).remove();
                $("#tdi_select_building_div" + widget_id).remove();
                $("#tdi_information_users" + widget_id).show(); // a hided html-element, will be shown again
                $("#tdi_select_users" + widget_id).show();
                $("#tdi_button_back" + widget_id).attr("disabled", true);
                break;

            case "state: choose file":
                current_state = "state: choose building"; // previous click-state

                // html-content, which has to be deleted
                if (last_insert_process == "AUTOMATICALLY STOPPED") {
                    $("#tdi_information_stopped_div" + widget_id).remove(); // removes the html-element, and its children, by entered id
                    $("#tdi_lif_" + widget_id).remove();
                } else {
                    $("#tdi_information_file_div" + widget_id).remove();
                    $("#tdi_data_file_div" + widget_id).remove();
                    $("#tdi_select_data_file_div" + widget_id).remove();
                    $("#tdi_button_trash_div" + widget_id).remove();
                }

                // additional css-style
                $("#tdi_button_back" + widget_id).css({left: 32.5 + '%'});
                $("#tdi_button_next" + widget_id).css({left: 52.5 + '%'});

                // additional html-element-activations
                $("#tdi_information_building" + widget_id).show();
                $("#tdi_select_building" + widget_id).show();
                break;

            case "state: choose day of current month":
                if (last_insert_process == "AUTOMATICALLY STOPPED") {
                    current_state = "state: choose building"; // previous click-state

                    // html-content, which has to be deleted
                    $("#tdi_information_stopped_div" + widget_id).remove();
                    $("#tdi_lif_" + widget_id).remove();

                    // additional css-style, and html-element-activations
                    $("#tdi_information_building" + widget_id).show();
                    $("#tdi_select_building" + widget_id).show();
                }
                else {
                    current_state = "state: choose file"; // previous click-state

                    // html-content, which has to be deleted
                    $("#tdi_information_days_div" + widget_id).remove();
                    $("#tdi_data_days_div" + widget_id).remove();
                    $("#tdi_information_days_2_div" + widget_id).remove();
                    $("#tdi_select_days_div" + widget_id).remove();

                    // additional css-style, and html-element-activations
                    $("#tdi_button_back" + widget_id).css({left: 22.5 + '%'});
                    $("#tdi_button_next" + widget_id).css({left: 42.5 + '%'});
                    $("#tdi_button_trash" + widget_id).css({left: 62.5 + '%'});

                    $("#tdi_information_file" + widget_id).show();
                    $("#tdi_data_file" + widget_id).show();
                    $("#tdi_select_data_file" + widget_id).show();
                    $("#tdi_button_trash" + widget_id).show();
                }
                break;

            case "state: choose rows":
                current_state = "state: choose day of current month"; // previous click-state

                // html-content, which has to be deleted
                $("#tdi_information_rows_div" + widget_id).remove();
                $("#tdi_data_rows_div" + widget_id).remove();
                $("#tdi_information_rows_2_div" + widget_id).remove();
                $("#tdi_data_rows_2_div" + widget_id).remove();
                $("#tdi_select_rows_div" + widget_id).remove();

                // html-element-activations
                if (last_insert_process == "AUTOMATICALLY STOPPED") {
                    $("#tdi_information_stopped" + widget_id).show();
                    $("#tdi_lif_" + widget_id).show();
                } else {
                    $("#tdi_information_days" + widget_id).show();
                    $("#tdi_data_days" + widget_id).show();
                    $("#tdi_information_days_2" + widget_id).show();
                    $("#tdi_select_days" + widget_id).show();
                }
                break;

            case "state: start":
                current_state = "state: choose rows"; // previous click-state

                // html-content, which has to be deleted
                $("#tdi_information_selected_div" + widget_id).remove();
                $("#tdi_data_selected_div" + widget_id).remove();
                $("#tdi_data_selected_2_div" + widget_id).remove();
                $("#tdi_information_selected_2_div" + widget_id).remove();

                // additional html-element-activations
                $("#tdi_information_rows" + widget_id).show();
                $("#tdi_data_rows_1" + widget_id).show();
                $("#tdi_data_rows_2" + widget_id).show();
                $("#tdi_information_rows_2" + widget_id).show();
                $("#tdi_select_rows" + widget_id).show();
                break;

            case "state: start at line":
                if (last_insert_process == "AUTOMATICALLY STOPPED") {
                    current_state = "state: choose rows"; // previous click-state

                    // html-content, which has to be deleted
                    $("#tdi_information_selected_div" + widget_id).remove();
                    $("#tdi_data_selected_div" + widget_id).remove();
                    $("#tdi_data_selected_2_div" + widget_id).remove();
                    $("#tdi_information_selected_2_div" + widget_id).remove();

                    // additional html-element-activations
                    $("#tdi_information_rows" + widget_id).show();
                    $("#tdi_data_rows_1" + widget_id).show();
                    $("#tdi_data_rows_2" + widget_id).show();
                    $("#tdi_information_rows_2" + widget_id).show();
                    $("#tdi_select_rows" + widget_id).show();
                } else {
                    current_state = "state: choose building"; // previous click-state

                    // html-content, which has to be deleted
                    $("#tdi_information_stopped_div" + widget_id).remove();
                    $("#tdi_lif_" + widget_id).remove();

                    // additional html-element-activations
                    $("#tdi_information_building" + widget_id).show();
                    $("#tdi_select_building" + widget_id).show();
                }
                break;
        }
    }

    // fills the count of rows drop-down-list with content
    function selectRowsContent(cr_drop_down_list, line_counter, hour_counter, count_of_rows) {
        if (line_counter >= count_of_rows)
            $(cr_drop_down_list + widget_id).append('<option value="' + count_of_rows + '">' + hour_counter + ' h</option>');
        else {
            while (line_counter < count_of_rows) {
                $(cr_drop_down_list + widget_id).append('<option value="' + line_counter + '">' + hour_counter + ' h</option>');
                line_counter = line_counter + 3600;
                hour_counter++;
            }

            $(cr_drop_down_list + widget_id).append('<option value="' + count_of_rows + '">' + hour_counter + ' h</option>');
        }
    }

    // controls, where the insert process of the specific building has to be started - at the very beginning, at a special file/line
    function insertProcessPreparation() {
        var selectedBuilding = $("#tdi_select_building" + widget_id).find(':selected').text();
        var selectedUser = $("#tdi_select_users" + widget_id).find(':selected').text();
        window_width = $(window).innerWidth();
        current_screen_res = getScreenResolution();

        if (process_var == "BEGINNING") // if no insert process, of the current building, had been started
        {
            var selectedDataFile = $("#tdi_select_data_file" + widget_id).find(':selected').text();
            var selectedDay = $("#tdi_select_days" + widget_id).find(':selected').text();
            var count_of_rows = parseInt($("#tdi_select_rows" + widget_id).find(':selected').val());

            $.ajax
            ({
                type: "POST",
                url: "widgets/TestDataInput/core/tdi_ip_preparation.php",
                data: "user=" + selectedUser + "&process_var=" + process_var + "&building=" + selectedBuilding + "&ci_file=" + selectedDataFile + "&sel_day=" + selectedDay + "&count_of_rows=" + count_of_rows,
                success: function (data) {
                    var object, data_array;
                    object = JSON.parse(data);
                    data_array = object.data;

                    if(data_array[0] != "NO IP POSSIBLE")
                    {
                        if(data_array[0] != "FAILURE")
                        {
                            process_var = data_array[0]; // new insert process state

                            // html-content, which has to be added to this widget
                            box = '<div class="tdi-information-ip-prep"><p id="tdi_insert_key' + widget_id + '">' + data_array[4] + '</p></div>'
                                + '<div class="tdi-information-ip-prep"><p id="tdi_information_ip_prep' + widget_id + '">' + data_array[1] + '</p></div>'
                                + '<div class="tdi-information-ip-prep"><p id="tdi_information_ip_prep_2' + widget_id + '">The insert process starts in</p></div>'
                                + '<div class="tdi-data-ip-prep"><p id="tdi_data_ip_prep' + widget_id + '">5 seconds!</p></div>';

                            if (data_array[2].length == 9)
                                box = box + '<div class="tdi-unsorted-list"><ul id="tdi_device_list' + widget_id + '" style="top:21.5%;left:10%">';
                            else
                                box = box + '<div class="tdi-unsorted-list"><ul id="tdi_device_list' + widget_id + '" style="top:25%;left:10%">';

                            for (i = 0; i < data_array[2].length; i++) // inserted devices into the data base
                                box = box + '<li>' + data_array[2][i] + '</li>';

                            for (i = 0; i < data_array[3].length; i++) // needed devices for the input process
                                help_array_devices.push(data_array[3][i]);

                            box = box + '</ul></div>';
                            $("#test_data_input" + widget_id).append(box);

                            // additional css-style
                            $("#tdi_information_ip_prep" + widget_id).css({top: 4 + '%'});
                            $("#tdi_information_ip_prep" + widget_id).css({left: 5 + '%'});
                            $("#tdi_information_ip_prep" + widget_id).css({width: 90 + '%'});
                            var cur_res_object_fs = {tag_id:"tdi_information_ip_prep", indention:"font-size", value_1536x1000:13, value_1366x768:12 };
                            setActiveResValues(cur_res_object_fs);
                            $("#tdi_information_ip_prep" + widget_id).css({color: "#ffffff"});
                            $("#tdi_information_ip_prep_2" + widget_id).css({top: 88 + '%'});
                            $("#tdi_information_ip_prep_2" + widget_id).css({left: 5 + '%'});
                            $("#tdi_information_ip_prep_2" + widget_id).css({width: 60 + '%'});
                            var cur_res_object_02_fs = {tag_id:"tdi_information_ip_prep_2", indention:"font-size", value_1536x1000:13, value_1366x768:12 };
                            setActiveResValues(cur_res_object_02_fs);
                            $("#tdi_information_ip_prep_2" + widget_id).css({color: "#ffffff"});
                            $("#tdi_data_ip_prep" + widget_id).css({top: 88 + '%'});
                            var cur_res_object_left = {tag_id:"tdi_data_ip_prep", indention:"left", value_1920x1080:47, value_1536x1000:50, value_1366x768:56, value_800x1200:44};
                            setActiveResValues(cur_res_object_left);
                            $("#tdi_data_ip_prep" + widget_id).css({width: 25 + '%'});
                            var cur_res_object_03_fs = {tag_id:"tdi_data_ip_prep", indention:"font-size", value_1536x1000:13, value_1366x768:12};
                            setActiveResValues(cur_res_object_03_fs);
                            $("#tdi_data_ip_prep" + widget_id).css({color: "#ffff00"});
                            var cur_res_object_04_fs = {tag_id:"tdi_device_list", indention:"font-size", value_1536x1000:12, value_1366x768:9};
                            setActiveResValues(cur_res_object_04_fs);

                            if(data_array[2].length == 9) {
                                var cur_res_object_top = {tag_id:"tdi_information_ip_prep", indention:"top", value_1366x768:2 };
                                var cur_res_object_02_top = {tag_id:"tdi_information_ip_prep_2", indention:"top", value_1366x768:91 };
                                var cur_res_object_03_top = {tag_id:"tdi_data_ip_prep", indention:"top", value_1366x768:91 };
                                var cur_res_object_04_top = {tag_id:"tdi_device_list", indention:"top", value_1920x1080:19, value_1536x1000:17.5, value_1366x768:20, value_800x1200:19};
                                setActiveResValues(cur_res_object_top);
                                setActiveResValues(cur_res_object_02_top);
                                setActiveResValues(cur_res_object_03_top);
                                setActiveResValues(cur_res_object_04_top);
                            }
                            else {
                                var cur_res_object_top = {tag_id:"tdi_device_list", indention:"top", value_1920x1080:22.5, value_1536x1000:24, value_1366x768:24, value_800x1200:22.5};
                                setActiveResValues(cur_res_object_top);
                            }

                            // additional html-element-activations
                            $("#tdi_information_selected" + widget_id).hide();
                            $("#tdi_data_selected" + widget_id).hide();
                            $("#tdi_data_selected_2" + widget_id).hide();
                            $("#tdi_information_selected_2" + widget_id).hide();
                            $("#tdi_button_back" + widget_id).hide();
                            $("#tdi_button_next" + widget_id).hide();
                            $("#tdi_insert_key" + widget_id).hide();

                            current_file_ip = selectedDataFile;
                            element_id = "#tdi_data_ip_prep" + widget_id;
                            current_timer_id_counter = setInterval(timerIP, 1000);
                        } else failureHandlingIPPrep(data_array[1]);
                    }
                    else {
                        // html-content, which has to be added to this widget
                        box = '<div class="tdi-information"><p id="tdi_information' + widget_id + '">' + data_array[1] + '</p></div>'
                            + '<div class="tdi-button"><input id="tdi_button_retry' + widget_id + '" type="button" value="Retry"></div>';
                        $("#test_data_input" + widget_id).append(box);

                        // additional css-style
                        $("#tdi_information" + widget_id).css({top: 10 + '%'});
                        var cur_res_object_left = {tag_id:"tdi_information", indention:"left", value_1920x1080:20, value_1536x1000:20, value_1366x768:15, value_800x1200:20 };
                        var cur_res_object_width = {tag_id:"tdi_information", indention:"width", value_1366x768:70 };
                        setActiveResValues(cur_res_object_left);
                        setActiveResValues(cur_res_object_width);
                        $("#tdi_information" + widget_id).css({color: "#ffffff"});
                        $("#tdi_button_retry" + widget_id).css({left: 42.5 + '%'});

                        // event initialization
                        hover_leaveEvent("tdi_button_retry", "9d9d9d", "0000bf", "000000", "ffff00");
                        $("#tdi_button_retry" + widget_id).unbind("click");
                        $("#tdi_button_retry" + widget_id).on({
                            click: function () {
                                $("#test_data_input" + widget_id).empty(); // removes all content, inside the div-element test_data_input+widget_id
                                dashboard.getData();
                            }
                        });

                        // additional html-element-activations
                        $("#tdi_information_selected" + widget_id).hide();
                        $("#tdi_data_selected" + widget_id).hide();
                        $("#tdi_data_selected_2" + widget_id).hide();
                        $("#tdi_information_selected_2" + widget_id).hide();
                        $("#tdi_button_back" + widget_id).hide();
                        $("#tdi_button_next" + widget_id).hide();
                        $("#tdi_insert_key" + widget_id).hide();

                        process_var = data_array[0];
                    }
                }
            });
        } else if (process_var == "CONTINUE AT FILE") { // if one, or more data files, of the current building had been inserted before
            var selectedDataFile = $("#tdi_select_data_file" + widget_id).find(':selected').text();
            var selectedDay = $("#tdi_select_days" + widget_id).find(':selected').text();
            var count_of_rows = parseInt($("#tdi_select_rows" + widget_id).find(':selected').val());

            $.ajax
            ({
                type: "POST",
                url: "widgets/TestDataInput/core/tdi_ip_preparation.php",
                data: "user=" + selectedUser + "&process_var=" + process_var + "&building=" + selectedBuilding + "&ci_file=" + selectedDataFile + "&sel_day=" + selectedDay + "&count_of_rows=" + count_of_rows,
                success: function (data) {
                    var object, data_array;
                    object = JSON.parse(data);
                    data_array = object.data;

                    if(data_array[0] != "NO IP POSSIBLE")
                    {
                        if(data_array[0] != "FAILURE")
                        {
                            process_var = data_array[0]; // new input process state

                            for (i = 0; i < data_array[2].length; i++)
                                help_array_devices.push(data_array[2][i]);

                            // html-content, which has to be added to this widget
                            box = '<div class="tdi-information-ip-prep"><p id="tdi_insert_key' + widget_id + '">' + data_array[3] + '</p></div>'
                                + '<div class="tdi-information-ip-prep"><p id="tdi_information_ip_prep' + widget_id + '">' + data_array[1] + '</p></div>'
                                + '<div class="tdi-data-ip-prep"><p id="tdi_data_ip_prep' + widget_id + '">5 seconds!</p></div>';
                            $("#test_data_input" + widget_id).append(box);

                            // additional css-style
                            $("#tdi_information_ip_prep" + widget_id).css({top: 10 + '%'});
                            var cur_res_object_left = { tag_id:"tdi_information_ip_prep", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20 };
                            var cur_res_object_width = { tag_id:"tdi_information_ip_prep", indention:"width", value_1920x1080:60, value_1536x1000:70, value_1366x768:80, value_800x1200:60 };
                            setActiveResValues(cur_res_object_left);
                            setActiveResValues(cur_res_object_width);
                            $("#tdi_information_ip_prep" + widget_id).css({color: "#ffffff"});
                            $("#tdi_data_ip_prep" + widget_id).css({color: "#ffff00"});
                            var cur_res_object_02_left = { tag_id:"tdi_data_ip_prep", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20 };
                            var cur_res_object_02_top = { tag_id:"tdi_data_ip_prep", indention:"top", value_1920x1080:42, value_1536x1000:43, value_1366x768:42.5, value_800x1200:35 };
                            var cur_res_object_02_width = { tag_id:"tdi_data_ip_prep", indention:"width", value_1920x1080:25, value_1536x1000:25, value_1366x768:28, value_800x1200:25 };
                            setActiveResValues(cur_res_object_02_left);
                            setActiveResValues(cur_res_object_02_top);
                            setActiveResValues(cur_res_object_02_width);

                            // additional html-element-activations
                            $("#tdi_information_selected" + widget_id).hide();
                            $("#tdi_data_selected" + widget_id).hide();
                            $("#tdi_data_selected_2" + widget_id).hide();
                            $("#tdi_information_selected_2" + widget_id).hide();
                            $("#tdi_button_back" + widget_id).hide();
                            $("#tdi_button_next" + widget_id).hide();
                            $("#tdi_insert_key" + widget_id).hide();

                            current_file_ip = selectedDataFile;
                            element_id = "#tdi_data_ip_prep" + widget_id;
                            current_timer_id_counter = setInterval(timerIP, 1000);
                        } else failureHandlingIPPrep(data_array[1]);
                    }
                    else {
                        // html-content, which has to be added to this widget
                        box = '<div class="tdi-information"><p id="tdi_information' + widget_id + '">' + data_array[1] + '</p></div>'
                            + '<div class="tdi-button"><input id="tdi_button_retry' + widget_id + '" type="button" value="Retry"></div>';
                        $("#test_data_input" + widget_id).append(box);

                        // additional css-style
                        $("#tdi_information" + widget_id).css({top: 10 + '%'});
                        var cur_res_object_left = {tag_id:"tdi_information", indention:"left", value_1920x1080:20, value_1536x1000:20, value_1366x768:15, value_800x1200:20 };
                        var cur_res_object_width = {tag_id:"tdi_information", indention:"width", value_1366x768:70 };
                        setActiveResValues(cur_res_object_left);
                        setActiveResValues(cur_res_object_width);
                        $("#tdi_information" + widget_id).css({color: "#ffffff"});
                        $("#tdi_button_retry" + widget_id).css({left: 42.5 + '%'});

                        // event initialization
                        hover_leaveEvent("tdi_button_retry", "9d9d9d", "0000bf", "000000", "ffff00");
                        $("#tdi_button_retry" + widget_id).unbind("click");
                        $("#tdi_button_retry" + widget_id).on({
                            click: function () {
                                $("#test_data_input" + widget_id).empty(); // removes all content, inside the div-element test_data_input+widget_id
                                dashboard.getData();
                            }
                        });

                        // additional html-element-activations
                        $("#tdi_information_selected" + widget_id).hide();
                        $("#tdi_data_selected" + widget_id).hide();
                        $("#tdi_data_selected_2" + widget_id).hide();
                        $("#tdi_information_selected_2" + widget_id).hide();
                        $("#tdi_button_back" + widget_id).hide();
                        $("#tdi_button_next" + widget_id).hide();
                        $("#tdi_insert_key" + widget_id).hide();

                        process_var = data_array[0];
                    }
                }
            });
        } else if (process_var == "CONTINUE AT LINE") { // if the insert process, of the current building had been stopped automatically (insert process had reached count of rows, which had to be inserted), or through the user
            var ajax_data_line;

            if (last_insert_process == "AUTOMATICALLY STOPPED")
                ajax_data_line = "user=" + selectedUser + "&process_var=" + process_var + "&building=" + selectedBuilding + "&last_insert_process=" + last_insert_process + "&count_of_rows=" + $("#tdi_select_rows" + widget_id).find(':selected').val();
            else
                ajax_data_line = "user=" + selectedUser + "&process_var=" + process_var + "&building=" + selectedBuilding + "&last_insert_process=" + last_insert_process;

            $.ajax
            ({
                type: "POST",
                url: "widgets/TestDataInput/core/tdi_ip_preparation.php",
                data: ajax_data_line,
                success: function (data) {
                    var object, data_array;
                    object = JSON.parse(data);
                    data_array = object.data;

                    if(data_array[0] != "NO IP POSSIBLE")
                    {
                        if(data_array[0] != "FAILURE")
                        {
                            process_var = data_array[0]; // new input process state

                            for (i = 0; i < data_array[4].length; i++)
                                help_array_devices.push(data_array[4][i]);

                            current_length_pb = (parseFloat(data_array[2]) / parseFloat(data_array[3])) * 100;
                            current_pc_pb = Math.round(current_length_pb);

                            // html-content, which has to be added to this widget
                            box = '<div class="tdi-information-ip-prep"><p id="tdi_insert_key' + widget_id + '">' + data_array[5] + '</p></div>'
                                + '<div class="tdi-information-ip-prep"><p id="tdi_information_ip_prep' + widget_id + '">' + data_array[1] + '</p></div>'
                                + '<div class="tdi-data-ip-prep"><p id="tdi_data_ip_prep' + widget_id + '">5 seconds!</p></div>';
                            $("#test_data_input" + widget_id).append(box);

                            // additional css-style
                            $("#tdi_information_ip_prep" + widget_id).css({top: 10 + '%'});
                            var cur_res_object_left = { tag_id:"tdi_information_ip_prep", indention:"left", value_1920x1080:20, value_1536x1000:14.5, value_1366x768:10, value_800x1200:20 };
                            var cur_res_object_width = { tag_id:"tdi_information_ip_prep", indention:"width", value_1920x1080:60, value_1536x1000:71, value_1366x768:80, value_800x1200:60 };
                            setActiveResValues(cur_res_object_left);
                            setActiveResValues(cur_res_object_width);
                            $("#tdi_information_ip_prep" + widget_id).css({color: "#ffffff"});
                            $("#tdi_data_ip_prep" + widget_id).css({width: 25 + '%'});
                            $("#tdi_data_ip_prep" + widget_id).css({color: "#ffff00"});

                            // additional html-element-activations and css-style
                            if (last_insert_process == "AUTOMATICALLY STOPPED") {
                                $("#tdi_information_selected" + widget_id).hide();
                                $("#tdi_data_selected" + widget_id).hide();
                                $("#tdi_data_selected_2" + widget_id).hide();
                                $("#tdi_information_selected_2" + widget_id).hide();
                                $("#tdi_button_back" + widget_id).hide();
                                $("#tdi_button_next" + widget_id).hide();

                                // additional css-style for the current used screen format
                                var cur_res_object_02_left = { tag_id:"tdi_data_ip_prep", indention:"left", value_1920x1080:20, value_1536x1000:14.5, value_1366x768:10, value_800x1200:20 };
                                var cur_res_object_02_top = { tag_id:"tdi_data_ip_prep", indention:"top", value_1920x1080:43, value_1536x1000:50, value_1366x768:50, value_800x1200:43 };
                                setActiveResValues(cur_res_object_02_left);
                                setActiveResValues(cur_res_object_02_top);
                            } else {
                                $("#tdi_information_stopped" + widget_id).hide();
                                $("#tdi_lif_" + widget_id).hide();
                                $("#tdi_button_back" + widget_id).hide();
                                $("#tdi_button_next" + widget_id).hide();

                                // additional css-style for the current used screen format
                                var cur_res_object_03_left = { tag_id:"tdi_data_ip_prep", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20 };
                                var cur_res_object_03_top = { tag_id:"tdi_data_ip_prep", indention:"top", value_1920x1080:42, value_1536x1000:43, value_1366x768:43, value_800x1200:42 };
                                setActiveResValues(cur_res_object_03_left);
                                setActiveResValues(cur_res_object_03_top);
                            }

                            $("#tdi_insert_key" + widget_id).hide();

                            var cur_res_object_0203_width = { tag_id:"tdi_data_ip_prep", indention:"width", value_1920x1080:25, value_1536x1000:25, value_1366x768:28, value_800x1200:25 };
                            setActiveResValues(cur_res_object_0203_width);

                            var log_id = $("#tdi_lif_log_id_" + widget_id).text();
                            var last_current_row = $("#tdi_lif_cl_" + widget_id).val();
                            var log_id_array = log_id.split(" ");
                            current_file_ip = log_id_array[1];
                            current_row = parseInt(last_current_row);
                            current_row_expected = current_row;
                            element_id = "#tdi_data_ip_prep" + widget_id;
                            current_timer_id_counter = setInterval(timerIP, 1000);
                        } else failureHandlingIPPrep(data_array[1]);
                    }
                    else {
                        // html-content, which has to be added to this widget
                        box = '<div class="tdi-information"><p id="tdi_information' + widget_id + '">' + data_array[1] + '</p></div>'
                            + '<div class="tdi-button"><input id="tdi_button_retry' + widget_id + '" type="button" value="Retry"></div>';
                        $("#test_data_input" + widget_id).append(box);

                        // additional css-style
                        $("#tdi_information" + widget_id).css({top: 10 + '%'});
                        var cur_res_object_left = {tag_id:"tdi_information", indention:"left", value_1920x1080:20, value_1536x1000:20, value_1366x768:15, value_800x1200:20 };
                        var cur_res_object_width = {tag_id:"tdi_information", indention:"width", value_1366x768:70 };
                        setActiveResValues(cur_res_object_left);
                        setActiveResValues(cur_res_object_width);
                        $("#tdi_information" + widget_id).css({color: "#ffffff"});
                        $("#tdi_button_retry" + widget_id).css({left: 42.5 + '%'});

                        // event initialization
                        hover_leaveEvent("tdi_button_retry", "9d9d9d", "0000bf", "000000", "ffff00");
                        $("#tdi_button_retry" + widget_id).unbind("click");
                        $("#tdi_button_retry" + widget_id).on({
                            click: function () {
                                $("#test_data_input" + widget_id).empty(); // removes all content, inside the div-element test_data_input+widget_id
                                dashboard.getData();
                            }
                        });

                        // additional html-element-activations
                        if (last_insert_process == "AUTOMATICALLY STOPPED") {
                            $("#tdi_information_selected" + widget_id).hide();
                            $("#tdi_data_selected" + widget_id).hide();
                            $("#tdi_data_selected_2" + widget_id).hide();
                            $("#tdi_information_selected_2" + widget_id).hide();
                            $("#tdi_button_back" + widget_id).hide();
                            $("#tdi_button_next" + widget_id).hide();
                        } else {
                            $("#tdi_information_stopped" + widget_id).hide();
                            $("#tdi_lif_" + widget_id).hide();
                            $("#tdi_button_back" + widget_id).hide();
                            $("#tdi_button_next" + widget_id).hide();
                        }

                        process_var = data_array[0];
                    }
                }
            });
        }
    }

    function failureHandlingIPPrep(e_message) {
        // html-content, which has to be added to this widget
        $("#test_data_input" + widget_id).empty();
        box = '<div class="tdi-information-ip-prep"><p id="tdi_information_ip_prep_failure' + widget_id + '">' + e_message + '</p></div>'
            + '<div class="tdi-button"><input id="tdi_button_retry' + widget_id + '" type="button" value="Retry"></div>';
        $("#test_data_input" + widget_id).append(box);

        // additional css-style
        $("#tdi_information_ip_prep_failure" + widget_id).css({top: 10 + '%'});
        var cur_res_object_left = { tag_id:"tdi_information_ip_prep_failure", indention:"left", value_1920x1080:20, value_1536x1000:14.5, value_1366x768:10, value_800x1200:20 };
        var cur_res_object_width = { tag_id:"tdi_information_ip_prep_failure", indention:"width", value_1920x1080:60, value_1536x1000:71, value_1366x768:80, value_800x1200:60 };
        setActiveResValues(cur_res_object_left);
        setActiveResValues(cur_res_object_width);
        $("#tdi_information_ip_prep_failure" + widget_id).css({color: "#ffffff"});
        $("#tdi_button_retry" + widget_id).css({left: 42.5 + '%'});

        // event initialization
        hover_leaveEvent("tdi_button_retry", "9d9d9d", "0000bf", "000000", "ffff00");
        $("#tdi_button_retry" + widget_id).unbind("click");
        $("#tdi_button_retry" + widget_id).on({
            click: function () {
                $("#test_data_input" + widget_id).empty(); // removes all content, inside the div-element test_data_input+widget_id
                dashboard.getData();
            }
        });
    }

    // simulates a countdown
    function timerIP() {
        if (timer_index > 0) {
            $(element_id).text(timer_index + " seconds!");
            timer_index = timer_index - 1;
        } else {
            if (element_id == ("#tdi_data_ip_prep" + widget_id)) {
                clearInterval(current_timer_id_counter); // deletes the interval-event, of the entered interval-id
                drawInsertProcess(help_array_devices, current_file_ip);
            } else if (element_id == ("#tdi_input_process_infotext_stop_counter" + widget_id)) {
                clearInterval(current_timer_id_counter);
                ipDelete(process_var, st_as_fs_text);
            } else {
                clearInterval(current_timer_id_counter);
                ipDelete(process_var, st_as_fs_text);
            }
        }
    }

    // draws the insert process simulation block
    function drawInsertProcess(used_devs, selected_data_file) {
        var selectedBuilding = $("#tdi_select_building" + widget_id).find(':selected').text();
        var selectedUser = $("#tdi_select_users" + widget_id).find(':selected').text();
        window_width = $(window).innerWidth();
        current_screen_res = getScreenResolution();

        $("#overlay").css("display", "block"); // activates the overlay div
        $("#overlay").append('<div id="tdi_input_process_overlay' + widget_id + '" class="tdi-input-process-transparent"></div>'); // appends the transparent div to the overlay div
        $("#tdi_input_process_overlay" + widget_id).append('<div id="tdi_input_process_dialog' + widget_id + '" class="tdi-input-process-main-view"></div>'); // input process dialog

        // draws the main content of the input process dialog
        // html-content, which has to be added to this dialog
        box = '<div id="tdi_input_process_title_line' + widget_id + '" class="tdi-input-process-title-line"><p id="tdi_input_process_title' + widget_id + '">TDI - Input process for ' + selectedUser + ' and ' + selectedBuilding + '<p></div>'
            + '<div class="tdi-input-process-text"><p id="tdi_input_process_infotext' + widget_id + '">Current inserting file: </p></div>'
            + '<div class="tdi-input-process-text"><p id="tdi_input_process_file' + widget_id + '">' + selected_data_file + '</p></div>'
            + '<div class="tdi-input-process-infotext"><p id="tdi_input_process_infotext_stop' + widget_id + '">Attention</p></div>'
            + '<div class="tdi-input-process-infotext-counter"><p id="tdi_input_process_infotext_stop_counter' + widget_id + '">seconds</p></div>'
            + '<div class="tdi-input-process-infotext"><p id="tdi_input_process_infotext_break' + widget_id + '">Attention</p></div>'
            + '<div class="tdi-input-process-infotext"><p id="tdi_input_process_infotext_fs_as' + widget_id + '">Attention</p></div>'
            + '<div class="tdi-input-process-infotext-counter"><p id="tdi_input_process_infotext_fs_as_counter' + widget_id + '">seconds</p></div>'
            + '<div id="tdi_input_process_table' + widget_id + '" class="tdi-input-process-table"></div>'
            + '<div id="tdi_input_process_outer_pb' + widget_id + '" class="tdi-input-process-outer-rectangular"></div>'
            + '<div class="tdi-input-process-button"><input id="tdi_input_process_break' + widget_id + '" type="button" value="BREAK"></div>'
            + '<div class="tdi-input-process-button"><input id="tdi_input_process_continue' + widget_id + '" type="button" value="CONTINUE"></div>'
            + '<div class="tdi-input-process-button"><input id="tdi_input_process_stop' + widget_id + '" type="button" value="STOP"></div>';
        $("#tdi_input_process_dialog" + widget_id).append(box);
        $("#tdi_input_process_outer_pb" + widget_id).append('<div id="tdi_input_process_inner_pb' + widget_id + '" class="tdi-input-process-inner-rectangular"></div>');
        $("#tdi_input_process_outer_pb" + widget_id).append('<div class="tdi-input-process-inner-rectangular-text"><p id="tdi_input_process_inner_pb_text' + widget_id + '">' + current_pc_pb + ' %</p></div>');

        // additional css-style
        $("#tdi_input_process_infotext" + widget_id).css({left: 2.5 + '%'});
        $("#tdi_input_process_infotext" + widget_id).css({color: "#ffffff"});
        var cur_res_object_fs = { tag_id:"tdi_input_process_infotext", indention:"font-size", value_1366x768:14 };
        var cur_res_object_02_left = { tag_id:"tdi_input_process_file", indention:"left", value_1920x1080:20, value_1536x1000:25, value_1366x768:18.5, value_800x1200:25 };
        var cur_res_object_02_fs = { tag_id:"tdi_input_process_file", indention:"font-size", value_1366x768:14 };
        setActiveResValues(cur_res_object_fs);
        setActiveResValues(cur_res_object_02_left);
        setActiveResValues(cur_res_object_02_fs);
        $("#tdi_input_process_file" + widget_id).css({color: "#ffff00"});
        $("#tdi_input_process_infotext_stop" + widget_id).css({color: "#F03030"});
        var cur_res_object_03_top = { tag_id:"tdi_input_process_infotext_break", indention:"top", value_1920x1080:14, value_1536x1000:14, value_1366x768:12, value_800x1200:14 };
        setActiveResValues(cur_res_object_03_top);
        $("#tdi_input_process_infotext_break" + widget_id).css({left: 53 + '%'});
        $("#tdi_input_process_infotext_break" + widget_id).css({width: 45 + '%'});
        $("#tdi_input_process_infotext_break" + widget_id).css({color: "#FFA500"});
        var cur_res_object_04_width = { tag_id:"tdi_input_process_infotext_fs_as", indention:"width", value_1366x768:42.5 };
        setActiveResValues(cur_res_object_04_width);
        $("#tdi_input_process_infotext_fs_as" + widget_id).css({color: "#008B00"});
        var cur_res_object_06_left = { tag_id:"tdi_input_process_infotext_stop_counter", indention:"left", value_1920x1080:57, value_1536x1000:67.8, value_1366x768:61.5, value_800x1200:68 };
        var cur_res_object_06_top = { tag_id:"tdi_input_process_infotext_stop_counter", indention:"top", value_1920x1080:16.6, value_1536x1000:17.50, value_1366x768:17, value_800x1200:17.75 };
        var cur_res_object_07_left = { tag_id:"tdi_input_process_infotext_fs_as_counter", indention:"left", value_1920x1080:65.5, value_1536x1000:79, value_1366x768:65.5, value_800x1200:82.5 };
        var cur_res_object_07_top = { tag_id:"tdi_input_process_infotext_fs_as_counter", indention:"top", value_1920x1080:16.6, value_1536x1000:17.50, value_1366x768:17, value_800x1200:17.75 };
        setActiveResValues(cur_res_object_06_left);
        setActiveResValues(cur_res_object_06_top);
        setActiveResValues(cur_res_object_07_left);
        setActiveResValues(cur_res_object_07_top);

        $("#tdi_input_process_inner_pb" + widget_id).css({width: current_length_pb + '%'});
        $("#tdi_input_process_break" + widget_id).css({top: 77.5 + '%'});
        $("#tdi_input_process_break" + widget_id).css({left: 27 + '%'});
        $("#tdi_input_process_break" + widget_id).css({width: 12 + '%'});
        $("#tdi_input_process_continue" + widget_id).css({top: 77.5 + '%'});
        var cur_res_object_08_left = { tag_id:"tdi_input_process_continue", indention:"left", value_1920x1080:44, value_1536x1000:44, value_1366x768:42, value_800x1200:44 };
        var cur_res_object_08_width = { tag_id:"tdi_input_process_continue", indention:"width", value_1920x1080:12, value_1536x1000:12, value_1366x768:16, value_800x1200:12 };
        setActiveResValues(cur_res_object_08_left);
        setActiveResValues(cur_res_object_08_width);
        $("#tdi_input_process_continue" + widget_id).css({background: "#9d9d9d"});
        $("#tdi_input_process_stop" + widget_id).css({top: 77.5 + '%'});
        $("#tdi_input_process_stop" + widget_id).css({left: 61 + '%'});
        $("#tdi_input_process_stop" + widget_id).css({width: 12 + '%'});

        // additional html-element-activations
        $("#tdi_input_process_infotext_stop" + widget_id).hide();
        $("#tdi_input_process_infotext_stop_counter" + widget_id).hide();
        $("#tdi_input_process_infotext_break" + widget_id).hide();
        $("#tdi_input_process_infotext_fs_as" + widget_id).hide();
        $("#tdi_input_process_infotext_fs_as_counter" + widget_id).hide();
        $("#tdi_input_process_continue" + widget_id).attr("disabled", true);

        // event initialization
        $("#tdi_input_process_break" + widget_id).unbind("click");
        $("#tdi_input_process_break" + widget_id).on({
            click: function () {
                ipSetBreak();
            }
        });
        $("#tdi_input_process_continue" + widget_id).unbind("click");
        $("#tdi_input_process_continue" + widget_id).on({
            click: function () {
                ipSetContinue();
            }
        });
        $("#tdi_input_process_stop" + widget_id).unbind("click");
        $("#tdi_input_process_stop" + widget_id).on({
            click: function () {
                ipSetStop();
            }
        });

        // draws the last lines table of the input process dialog
        // html-content, which has to be added to this table
        box = '<table border="0" style="width:100%;" align="center" cellspacing="5">'
            + '<tr><td id="tdi_input_process_table_title' + widget_id + '" colspan="' + (used_devs.length + 1) + '" style="text-align:center;color:white;padding: 5px 0px 5px 0px;border:#f4ea5a 1px solid;background: #F03030;font-size: 14px">'
            + 'Last inserted hours of the ' + used_devs.length + ' devices for ' + selectedBuilding + ' in Ws</td></tr>'
            + '<tr style="text-align:center;color:white">'
            + '<td style="border:#f4ea5a 1px solid;background: #2B7CE9;font-size: 13px;padding: 2px 2px 2px 2px;">Hour</td>';

        for (i = 0; i < used_devs.length; i++) // inserts the current used devices -> column title
            box = box + '<td id="used_device' + i + '" style="border:#f4ea5a 1px solid;background: #2B7CE9;font-size: 13px;padding: 2px 2px 2px 2px;">' + used_devs[i] + '</td>';

        box = box + '</tr>';

        for (j = 0; j < 2; j++) // draws the previous and next data line, of the current used devices
        {
            box = box + '<tr style="text-align:center;color:black">'
                + '<td id="tdi_table_line' + j + '" style="border:#f4ea5a 1px solid;background: silver;font-size: 11px;padding: 2px 4px 2px 4px;">0</td>';

            for (k = 0; k < used_devs.length; k++) {
                if (j == 0)
                    box = box + '<td id="tdi_table_' + used_devs[k] + '_prev' + widget_id + '" style="border:#f4ea5a 1px solid;background: silver;font-size: 11px;padding: 2px 4px 2px 4px;">0</td>';
                else
                    box = box + '<td id="tdi_table_' + used_devs[k] + '_next' + widget_id + '" style="border:#f4ea5a 1px solid;background: silver;font-size: 11px;padding: 2px 4px 2px 4px;">0</td>';
            }

            box = box + '</tr>';
        }

        box = box + '</table>';
        $("#tdi_input_process_table" + widget_id).append(box);

        current_timer_id_ip = setInterval(insertProcess, 1000);
    }

    // simulates the test data insert process through a simulation block
    function insertProcess() {
        var selectedBuilding = $("#tdi_select_building" + widget_id).find(':selected').text();
        var selectedUser = $("#tdi_select_users" + widget_id).find(':selected').text();
        window_width = $(window).innerWidth();
        current_screen_res = getScreenResolution();

        if ((process_var == "NEXT LINES") && (current_row_expected < current_count_of_rows) && (current_row == current_row_expected)) {
            current_row_expected = current_row_expected + 240;

            $.ajax
            ({
                type: "POST",
                url: "widgets/TestDataInput/core/tdi_input_process.php",
                data: "authkey=" + dashboard.key + "&user=" + selectedUser + "&building=" + selectedBuilding + "&current_row=" + current_row + "&current_row_expected=" + current_row_expected,
                success: function (data) {
                    var object, data_array, help_variable_data, current_date;
                    object = JSON.parse(data);
                    data_array = object.data;

                    // swaps the last inserted lines table content
                    // swaps the column contents "Line"
                    help_variable_data = $("#tdi_table_line1").text();
                    $("#tdi_table_line0").text(help_variable_data);
                    current_date = new Date(data_array[2] * 1000); // creates a new date-object of the unix-timestamp; the timestamp will be converted into milliseconds
                    $("#tdi_table_line1").text(current_date.getHours() + ":" + current_date.getMinutes());

                    // swaps the column contents of the devices
                    for (i = 0; i < data_array[0].length; i++) {
                        help_variable_data = $("#tdi_table_" + help_array_devices[i] + "_next" + widget_id).text();
                        $("#tdi_table_" + help_array_devices[i] + "_prev" + widget_id).text(help_variable_data);
                        $("#tdi_table_" + help_array_devices[i] + "_next" + widget_id).text(data_array[0][i]);
                        console.log("#tdi_table_" + help_array_devices[i] + "_next" + widget_id + ": " + $("#tdi_table_" + help_array_devices[i] + "_next" + widget_id).text()); // probleme beim Einfügen
                    }

                    current_length_pb = (data_array[1] / current_count_of_rows) * 100; // computes the current length of the inner process bar
                    current_pc_pb = Math.round(current_length_pb);
                    $("#tdi_input_process_inner_pb" + widget_id).css({width: current_length_pb + '%'}); // refreshes the inner process bar length
                    $("#tdi_input_process_inner_pb_text" + widget_id).text(current_pc_pb + " %"); // refreshes the inner process bar text in per cent

                    if (current_row_expected == current_count_of_rows) {
                        $("#tdi_input_process_stop" + widget_id).attr("disabled", true);
                        $("#tdi_input_process_stop" + widget_id).css({background: "#9d9d9d"});
                    }

                    current_row = parseInt(data_array[1]);
                }
            });
        } else if ((process_var == "STOP") && (current_row_expected < current_count_of_rows)) {
            clearInterval(current_timer_id_ip);
            var used_insert_key = $("#tdi_insert_key" + widget_id).text();

            $.ajax
            ({
                type: "POST",
                url: "widgets/TestDataInput/core/tdi_ip_stop.php",
                data: "user=" + selectedUser + "&building=" + selectedBuilding + "&insert_key=" + used_insert_key,
                success: function (data) {
                    var object, data_array;
                    object = JSON.parse(data);
                    data_array = object.data;

                    if(data_array[0] != "OUT OF TIME") {
                        $("#tdi_input_process_infotext_stop" + widget_id).text(data_array[0]);
                        $("#tdi_input_process_infotext_stop" + widget_id).show();
                        $("#tdi_input_process_infotext_stop_counter" + widget_id).text(data_array[1]);
                        $("#tdi_input_process_infotext_stop_counter" + widget_id).show();

                        timer_index = 5;
                        element_id = "#tdi_input_process_infotext_stop_counter" + widget_id;
                        st_as_fs_text = data_array[2];
                        current_timer_id_counter = setInterval(timerIP, 1000);
                    } else ipDelete("OUT OF TIME", data_array[1]);

                }
            });

            $("#tdi_input_process_continue" + widget_id).attr("disabled", true);
            $("#tdi_input_process_continue" + widget_id).css({background: "#9d9d9d"});
            $("#tdi_input_process_break" + widget_id).attr("disabled", true);
            $("#tdi_input_process_break" + widget_id).css({background: "#9d9d9d"});
            $("#tdi_input_process_stop" + widget_id).attr("disabled", true);
            $("#tdi_input_process_stop" + widget_id).css({background: "#9d9d9d"});
        } else if (current_row == current_count_of_rows) {
            clearInterval(current_timer_id_ip);

            if (current_count_of_rows != whole_count_of_rows)
                process_var = "AUTOMATICALLY STOPPED";
            else if (current_count_of_rows == whole_count_of_rows)
                process_var = "FINISHED SUCCESSFUL";

            $.ajax
            ({
                type: "POST",
                url: "widgets/TestDataInput/core/tdi_ip_as_fs.php",
                data: "user=" + selectedUser + "&building=" + selectedBuilding + "&process_var=" + process_var,
                success: function (data) {
                    var object, data_array;
                    object = JSON.parse(data);
                    data_array = object.data;

                    $("#tdi_input_process_infotext_fs_as" + widget_id).text(data_array[0]);
                    $("#tdi_input_process_infotext_fs_as" + widget_id).show();
                    $("#tdi_input_process_infotext_fs_as_counter" + widget_id).text(data_array[1]);
                    $("#tdi_input_process_infotext_fs_as_counter" + widget_id).show();

                    timer_index = 5;
                    element_id = "#tdi_input_process_infotext_fs_as_counter" + widget_id;
                    st_as_fs_text = data_array[2];
                    current_timer_id_counter = setInterval(timerIP, 1000);
                }
            });

            $("#tdi_input_process_break" + widget_id).attr("disabled", true);
            $("#tdi_input_process_break" + widget_id).css({background: "#9d9d9d"});
            $("#tdi_input_process_continue" + widget_id).attr("disabled", true);
            $("#tdi_input_process_continue" + widget_id).css({background: "#9d9d9d"});
            $("#tdi_input_process_stop" + widget_id).attr("disabled", true);
            $("#tdi_input_process_stop" + widget_id).css({background: "#9d9d9d"});
        }
    }

    $(document).ajaxError(function( event, jqxhr, settings, thrownError ) {
        if (settings.url == "widgets/TestDataInput/core/tdi_input_process.php") {
             ipDelete("NO SERVER", "Failure: No server connection is possible at the moment!");
        }
        else if (settings.url == "widgets/TestDataInput/core/tdi_delete_data.php") {
            trashProcessDesign("Failure: All the selected data have already been deleted!");
        }
    });

    // these functions are setting the input process states - "BREAK", "CONTINUE", "STOP"
    function ipSetBreak() { 
        clearInterval(current_timer_id_ip);
        var selectedBuilding = $("#tdi_select_building" + widget_id).find(':selected').text();
        var selectedUser = $("#tdi_select_users" + widget_id).find(':selected').text();
        process_var = "BREAK";
        ipSetBreakStyle();

        $.ajax
        ({
            type: "POST",
            url: "widgets/TestDataInput/core/tdi_ip_break_cont.php",
            data: "user=" + selectedUser + "&building=" + selectedBuilding + "&process_var=" + process_var,
            success: function (data) {
                var object, data_array;
                object = JSON.parse(data);
                data_array = object.data;

                $("#tdi_input_process_infotext_break" + widget_id).text(data_array[1]);
                $("#tdi_input_process_infotext_break" + widget_id).show();
            }
        });
    }

    function ipSetContinue() { 
        var selectedBuilding = $("#tdi_select_building" + widget_id).find(':selected').text();
        var selectedUser = $("#tdi_select_users" + widget_id).find(':selected').text();
        var used_insert_key = $("#tdi_insert_key" + widget_id).text();
        process_var = "CONTINUE";

        $.ajax
        ({
            type: "POST",
            url: "widgets/TestDataInput/core/tdi_ip_break_cont.php",
            data: "user=" + selectedUser + "&building=" + selectedBuilding + "&process_var=" + process_var + "&insert_key=" + used_insert_key,
            success: function (data) {
                var object, data_array;
                object = JSON.parse(data);
                data_array = object.data;

                if(data_array[0] != "CONTINUING IS STOPPED") {
                    process_var = data_array[1];
                    ipSetContStyle();
                    $("#tdi_input_process_infotext_break" + widget_id).text("");
                    $("#tdi_input_process_infotext_break" + widget_id).hide();
                    current_timer_id_ip = setInterval(insertProcess, 1000);
                }
                else ipDelete("CONTINUING IS STOPPED", data_array[1]);
            }
        });
    }

    function ipSetStop() { process_var = "STOP"; }

    // sets the style of the input process simulation block during the process state "BREAK"
    function ipSetBreakStyle() {
        $("#tdi_input_process_continue" + widget_id).attr("disabled", false);
        $("#tdi_input_process_break" + widget_id).attr("disabled", true);
        $("#tdi_input_process_stop" + widget_id).attr("disabled", true);

        $("#tdi_input_process_dialog" + widget_id).css({borderColor: "#9d9d9d"});
        $("#tdi_input_process_title_line" + widget_id).css({background: "#9d9d9d"});
        $("#tdi_input_process_file" + widget_id).css({color: "#9d9d9d"});
        $("#tdi_input_process_table_title" + widget_id).css({background: "#9d9d9d"});
        $("#tdi_input_process_inner_pb" + widget_id).css({background: "#9d9d9d"});
        $("#tdi_input_process_inner_pb" + widget_id).css({borderColor: "#9d9d9d"});
        $("#tdi_input_process_break" + widget_id).css({background: "#9d9d9d"});
        $("#tdi_input_process_continue" + widget_id).css({background: "#000000"});
        $("#tdi_input_process_stop" + widget_id).css({background: "#9d9d9d"});
    }

    // sets the style of the input process simulation block during the process state "CONTINUE"
    function ipSetContStyle() {
        $("#tdi_input_process_continue" + widget_id).attr("disabled", true);
        $("#tdi_input_process_break" + widget_id).attr("disabled", false);
        $("#tdi_input_process_stop" + widget_id).attr("disabled", false);

        $("#tdi_input_process_dialog" + widget_id).css({borderColor: "#FFFF00"});
        $("#tdi_input_process_title_line" + widget_id).css({background: "#000000"});
        $("#tdi_input_process_file" + widget_id).css({color: "#FFFF00"});
        $("#tdi_input_process_table_title" + widget_id).css({background: "#F03030"});
        $("#tdi_input_process_inner_pb" + widget_id).css({background: "#008000"});
        $("#tdi_input_process_inner_pb" + widget_id).css({borderColor: "#008000"});
        $("#tdi_input_process_break" + widget_id).css({background: "#000000"});
        $("#tdi_input_process_continue" + widget_id).css({background: "#9d9d9d"});
        $("#tdi_input_process_stop" + widget_id).css({background: "#000000"});
    }

    // deletes the input process simulation block, if the input process is finished successful, or the user pressed the Stop-Button
    function ipDelete(del_way, info_text) {
        window_width = $(window).innerWidth();
        current_screen_res = getScreenResolution();
        $("#overlay").empty(); // removes all added elements of the overlay-div
        $("#overlay").css("none", "block"); // deactivates the overlay div
        $("#overlay").hide();

        // additional html-element-activations
        if (((del_way == "STOP") || (del_way == "FINISHED SUCCESSFUL") || (del_way == "AUTOMATICALLY STOPPED") || (del_way == "NO SERVER") || (del_way == "CONTINUING IS STOPPED") || (del_way == "OUT OF TIME")) && ((process_var_help == "CONTINUE AT LINE") || (process_var_help == "CONTINUE AT FILE")) && ((last_insert_process == "STOP") || (last_insert_process == "AUTOMATICALLY STOPPED") || (last_insert_process == "END"))) {
            $("#tdi_information_ip_prep" + widget_id).hide();
            $("#tdi_data_ip_prep" + widget_id).hide();
        } else {
            $("#tdi_information_ip_prep" + widget_id).hide();
            $("#tdi_device_list" + widget_id).hide();
            $("#tdi_information_ip_prep_2" + widget_id).hide();
            $("#tdi_data_ip_prep" + widget_id).hide();
        }

        if(del_way == "NO SERVER") {
            // html-content, which has to be added to this widget
            box = '<div class="tdi-information"><p id="tdi_information' + widget_id + '">' + info_text + '</p></div>'
                + '<div class="tdi-button"><input id="tdi_button_retry' + widget_id + '" type="button" value="Retry"></div>';
            $("#test_data_input" + widget_id).append(box);

            // additional css-style
            $("#tdi_information" + widget_id).css({top: 10 + '%'});
            var cur_res_object_left = {tag_id:"tdi_information", indention:"left", value_1920x1080:20, value_1536x1000:20, value_1366x768:15, value_800x1200:20 };
            var cur_res_object_width = {tag_id:"tdi_information", indention:"width", value_1366x768:70 };
            setActiveResValues(cur_res_object_left);
            setActiveResValues(cur_res_object_width);
            $("#tdi_information" + widget_id).css({color: "#ffffff"});
            $("#tdi_button_retry" + widget_id).css({left: 42.5 + '%'});

            // event initialization
            hover_leaveEvent("tdi_button_retry", "9d9d9d", "0000bf", "000000", "ffff00");
            $("#tdi_button_retry" + widget_id).unbind("click");
            $("#tdi_button_retry" + widget_id).on({
                click: function () {
                    $("#test_data_input" + widget_id).empty(); // removes all content, inside the div-element test_data_input+widget_id
                    dashboard.getData();
                }
            });
        } else {
            // html-content, which has to be added to this widget
            box = '<div class="tdi-information"><p id="tdi_information_ip_fin' + widget_id + '">' + info_text + '</p>'
                + '<p id="tdi_information_ip_fin_2' + widget_id + '">Would you like to continue?</p></div>'
                + '<div class="tdi-button"><input id="tdi_button_yes' + widget_id + '" type="button" value="Yes"></div>'
                + '<div class="tdi-button"><input id="tdi_button_no' + widget_id + '" type="button" value="No"></div>';
            $("#test_data_input" + widget_id).append(box);

            // additional css-style
            $("#tdi_information_ip_fin" + widget_id).css({top: 6 + '%'});
            $("#tdi_information_ip_fin" + widget_id).css({left: 20 + '%'});
            var cur_res_object_left = { tag_id:"tdi_information_ip_fin", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20 };
            var cur_res_object_width = { tag_id:"tdi_information_ip_fin", indention:"width", value_1920x1080:60, value_1536x1000:70, value_1366x768:80, value_800x1200:60 };
            setActiveResValues(cur_res_object_left);
            setActiveResValues(cur_res_object_width);
            $("#tdi_information_ip_fin" + widget_id).css({color: "#ffffff"});
            var cur_res_object_02_top = { tag_id:"tdi_information_ip_fin_2", indention:"top", value_1920x1080:40, value_1536x1000:40, value_1366x768:40, value_800x1200:38.5 };
            var cur_res_object_02_left = { tag_id:"tdi_information_ip_fin_2", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20 };
            var cur_res_object_02_width = { tag_id:"tdi_information_ip_fin_2", indention:"width", value_1920x1080:60, value_1536x1000:70, value_1366x768:80, value_800x1200:65 };
            setActiveResValues(cur_res_object_02_top);
            setActiveResValues(cur_res_object_02_left);
            setActiveResValues(cur_res_object_02_width);
            $("#tdi_information_ip_fin_2" + widget_id).css({color: "#ffff00"});
            $("#tdi_button_yes" + widget_id).css({left: 30 + '%'});
            $("#tdi_button_no" + widget_id).css({left: 55 + '%'});

            // event initialization
            hover_leaveEvent("tdi_button_yes", "008B00", "0000bf", "000000", "ffff00");
            hover_leaveEvent("tdi_button_no", "F03030", "0000bf", "000000", "ffff00");
            $("#tdi_button_yes" + widget_id).unbind("click");
            $("#tdi_button_yes" + widget_id).on({
                click: function () {
                    continueYes();
                }
            });
            $("#tdi_button_no" + widget_id).unbind("click");
            $("#tdi_button_no" + widget_id).on({
                click: function () {
                    continueNo();
                }
            });

            // insert key deletion
            var selectedUser = $("#tdi_select_users" + widget_id).find(':selected').text();
            var selectedBuilding = $("#tdi_select_building" + widget_id).find(':selected').text();
            var used_insert_key = $("tdi_insert_key" + widget_id).text();
            var interrupt_method = "STOP NORMAL";

            $.ajax ({
                type: "POST",
                url: "widgets/TestDataInput/core/tdi_leave_current_tab.php",
                data: "insert_key=" + used_insert_key + "&user=" + selectedUser + "&building=" + selectedBuilding + "&interrupt_method=" + interrupt_method,
                success: function (data) {
                    var object, data_array;
                    object = JSON.parse(data);
                    data_array = object.data;
                    console.log(data_array[1]);
                }
            });
        }
    }

    // if the user decides to continue the inserting process with a new file
    function continueYes() {
        dashboard.getData(); // dashboard refreshing
    }

    // if the user negates to continue the inserting process
    function continueNo() {
        current_screen_res = getScreenResolution();

        // html-content, which has to be added to this widget
        box = '<div class="tdi-information"><p id="tdi_information_ip_contNo' + widget_id + '">The insert process has completely finished now!</p>'
            + '<p id="tdi_information_ip_contNo_2' + widget_id + '">You can already close this widget!</p></div>';
        $("#test_data_input" + widget_id).append(box);

        // additional css-style
        $("#tdi_information_ip_contNo" + widget_id).css({top: 10 + '%'});
        var cur_res_object_left = { tag_id:"tdi_information_ip_contNo", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20 };
        var cur_res_object_width = { tag_id:"tdi_information_ip_contNo", indention:"width", value_1920x1080:60, value_1536x1000:70, value_1366x768:80, value_800x1200:60 };
        setActiveResValues(cur_res_object_left);
        setActiveResValues(cur_res_object_width);
        $("#tdi_information_ip_contNo" + widget_id).css({color: "#ffffff"});
        $("#tdi_information_ip_contNo_2" + widget_id).css({top: 27.5 + '%'});
        var cur_res_object_02_left = { tag_id:"tdi_information_ip_contNo_2", indention:"left", value_1920x1080:20, value_1536x1000:15, value_1366x768:10, value_800x1200:20 };
        var cur_res_object_02_width = { tag_id:"tdi_information_ip_contNo_2", indention:"width", value_1920x1080:60, value_1536x1000:70, value_1366x768:80, value_800x1200:60 };
        setActiveResValues(cur_res_object_02_left);
        setActiveResValues(cur_res_object_02_width);
        $("#tdi_information_ip_contNo_2" + widget_id).css({color: "#ffff00"});

        // additional html-element-activations
        $("#tdi_information_ip_fin" + widget_id).hide();
        $("#tdi_information_ip_fin_2" + widget_id).hide();
        $("#tdi_button_yes" + widget_id).hide();
        $("#tdi_button_no" + widget_id).hide();
        $("#cell" + cell_id + "remove").show();
    }

    // will be executed, when the tab, or the browser will be closed, or reloaded
    window.addEventListener('beforeunload', function (e) {
        e.preventDefault();
        e.returnValue = '';

        // insert key deletion
        if ((process_var == "NEXT LINES") || (process_var == "BREAK")) {
            clearInterval(current_timer_id_ip);
            var selectedUser = $("#tdi_select_users" + widget_id).find(':selected').text();
            var selectedBuilding = $("#tdi_select_building" + widget_id).find(':selected').text();
            var used_insert_key = $("#tdi_insert_key" + widget_id).text();
            var interrupt_method = "STOP BY HARD";

            $.ajax ({
                type: "POST",
                url: "widgets/TestDataInput/core/tdi_leave_current_tab.php",
                data: "insert_key=" + used_insert_key + "&user=" + selectedUser + "&building=" + selectedBuilding + "&interrupt_method=" + interrupt_method,
                success: function (data) {
                    var object, data_array;
                    object = JSON.parse(data);
                    data_array = object.data;
                    console.log(data_array[1]);
                }
            });
        }
        else console.log("Tab, or browser will be closed in few seconds!");
    });

    /** Trash-Data-Process **/
    // draws the trash-data-process dialog
    function drawTrashProcess() {
        var selectedBuilding = $("#tdi_select_building" + widget_id).find(':selected').text();
        var selectedUser = $("#tdi_select_users" + widget_id).find(':selected').text();
        window_width = $(window).innerWidth();
        current_screen_res = getScreenResolution();

        $("#overlay").css("display", "block");
        $("#overlay").append('<div id="tdi_trash_process_overlay' + widget_id + '" class="tdi-trash-process-transparent"></div>');
        $("#tdi_trash_process_overlay" + widget_id).append('<div id="tdi_trash_process_dialog' + widget_id + '" class="tdi-trash-process-main-view"></div>');

        // draws the main content of the trash process dialog
        // html-content, which has to be added to this dialog
        box = '<div id="tdi_trash_process_title_line' + widget_id + '" class="tdi-trash-process-title-line"><p id="tdi_trash_process_title' + widget_id + '">TDI - Trash process<p></div>'
            + '<div id="tdi_trash_process_detail_view' + widget_id + '" class="tdi-trash-process-detail-view"></div>';
        $("#tdi_trash_process_dialog" + widget_id).append(box);

        box = '<div class="tdi-trash-process-text"><p id="tdi_trash_process_information' + widget_id + '">If you want to delete all the test data (data lines, and information files) of user ' + selectedUser + ' of ' + selectedBuilding + ', press the Yes-button!</p></div>'
            + '<div class="tdi-trash-process-text"><p id="tdi_trash_process_commit_text' + widget_id + '">Information</p></div>'
            + '<div class="tdi-trash-process-button"><input id="tdi_trash_process_yes' + widget_id + '" type="button" value="Yes"></div>'
            + '<div class="tdi-trash-process-button"><input id="tdi_trash_process_no' + widget_id + '" type="button" value="No"></div>'
            + '<div class="tdi-trash-process-button"><input id="tdi_trash_process_ok' + widget_id + '" type="button" value="OK"></div>';
        $("#tdi_trash_process_detail_view" + widget_id).append(box);

        // additional css-styles
        $("#tdi_trash_process_information" + widget_id).css({color: "#ffffff"});
        $("#tdi_trash_process_commit_text" + widget_id).css({color: "#ffffff"});
        $("#tdi_trash_process_yes" + widget_id).css({top: 65 + '%'});
        $("#tdi_trash_process_yes" + widget_id).css({left: 32.5 + '%'});
        $("#tdi_trash_process_yes" + widget_id).css({width: 15 + '%'});
        $("#tdi_trash_process_no" + widget_id).css({top: 65 + '%'});
        $("#tdi_trash_process_no" + widget_id).css({left: 52.5 + '%'});
        $("#tdi_trash_process_no" + widget_id).css({width: 15 + '%'});
        $("#tdi_trash_process_ok" + widget_id).css({top: 65 + '%'});
        $("#tdi_trash_process_ok" + widget_id).css({left: 42.5 + '%'});
        $("#tdi_trash_process_ok" + widget_id).css({width: 15 + '%'});

        // additional html-element-activations
        $("#tdi_trash_process_commit_text" + widget_id).hide();
        $("#tdi_trash_process_ok" + widget_id).hide();

        // event initialization
        hover_leaveEvent("tdi_trash_process_yes", "008B00", "0000bf", "000000", "ffff00");
        hover_leaveEvent("tdi_trash_process_no", "F03030", "0000bf", "000000", "ffff00");
        hover_leaveEvent("tdi_trash_process_ok", "9d9d9d", "0000bf", "000000", "ffff00");
        $("#tdi_trash_process_yes" + widget_id).unbind("click");
        $("#tdi_trash_process_yes" + widget_id).on({
            click: function () {
                trashProcess(selectedUser, selectedBuilding);
            }
        });
        $("#tdi_trash_process_no" + widget_id).unbind("click");
        $("#tdi_trash_process_no" + widget_id).on({
            click: function () {
                tpDelete();
            }
        });
        $("#tdi_trash_process_ok" + widget_id).unbind("click");
        $("#tdi_trash_process_ok" + widget_id).on({
            click: function () {
                tpDelete();
                if(trash_process_using != "NO DATA NEEDED") {dashboard.getData();}
            }
        });
    }

    // sends a request to the server, that he has to delete all test data (buildings, devices, consumptionevents, temporary files, ...)
    function trashProcess(selectedUser, selectedBuilding) {
        $.ajax
        ({
            type: "POST",
            url: "widgets/TestDataInput/core/tdi_delete_data.php",
            data: "user=" + selectedUser + "&building=" + selectedBuilding,
            success: function (data) {
                var object, data_array;
                object = JSON.parse(data);
                data_array = object.data;

                trashProcessDesign(data_array[0]);
            }
        });
    }

    function trashProcessDesign(commit_text) {
        $("#tdi_trash_process_information" + widget_id).hide();
        $("#tdi_trash_process_yes" + widget_id).hide();
        $("#tdi_trash_process_no" + widget_id).hide();
        $("#tdi_trash_process_commit_text" + widget_id).text(commit_text);
        $("#tdi_trash_process_commit_text" + widget_id).show();
        $("#tdi_trash_process_ok" + widget_id).show();
    }

    // deletes the trash-data-process dialog
    function tpDelete() {
        $("#overlay").empty();
        $("#overlay").css("none", "block");
        $("#overlay").hide();
    }
</script>